import SwiftUI

struct SettingsView: View {
    @EnvironmentObject var app: AppState
    @State private var showKey = false

    var body: some View {
        NavigationStack {
            Form {
                Section("Free AI connection") {
                    HStack {
                        Label("Status", systemImage: "brain.head.profile")
                        Spacer()
                        Text(app.connectionState.rawValue)
                            .font(.caption.bold())
                            .foregroundStyle(app.connectionState == .live ? .green : .secondary)
                    }

                    if showKey {
                        TextField("sk-or-v1-…", text: $app.apiKeyInput)
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled()
                    } else {
                        SecureField("OpenRouter API key", text: $app.apiKeyInput)
                            .textInputAutocapitalization(.never)
                    }
                    Toggle("Show key", isOn: $showKey)
                    Button("Save key to iPhone Keychain") { app.saveAPIKey() }
                    Button {
                        Task { await app.testAI() }
                    } label: {
                        HStack {
                            Text(app.connectionState == .testing ? "Testing…" : "Test free AI connection")
                            if app.connectionState == .testing { Spacer(); ProgressView() }
                        }
                    }
                    .disabled(app.connectionState == .testing)

                    Link("Create a free OpenRouter API key", destination: URL(string: "https://openrouter.ai/keys")!)
                    Text("The default model is openrouter/free. OpenRouter currently offers free model inference with daily rate limits. Your key is stored in iOS Keychain.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                Section("Research mode") {
                    Toggle("Live web search", isOn: $app.liveWebSearch)
                        .onChange(of: app.liveWebSearch) { _ in app.save() }
                    if app.liveWebSearch {
                        Label("Uses OpenRouter's web-search tool", systemImage: "globe")
                            .font(.caption)
                        Text("This is NOT fully free. OpenRouter charges a small amount for web search. Turn it off to keep model inference on the free route only.")
                            .font(.caption)
                            .foregroundStyle(.orange)
                    } else {
                        Text("Free mode: the AI can analyse, plan, rank and create execution packs, but it must not claim its findings are live/current and may return no source links.")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                }

                Section("Agent") {
                    Picker("Model", selection: $app.selectedModel) {
                        ForEach(AgentModel.selectable) { model in Text(model.label).tag(model) }
                    }
                    .onChange(of: app.selectedModel) { _ in app.save() }
                    TextField("Region / market", text: $app.region).onSubmit { app.save() }
                    Picker("Autonomy", selection: $app.mode) {
                        ForEach(AgentMode.allCases, id: \.self) { Text($0.rawValue).tag($0) }
                    }
                    .onChange(of: app.mode) { _ in app.save() }
                    Text("WATCH researches only. ASSIST asks before preparing work. AUTOPILOT is still approval-gated for external or high-impact actions.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                Section("What works") {
                    Label("Free AI reasoning", systemImage: "brain")
                    Label("Opportunity scoring", systemImage: "chart.bar")
                    Label("Mission planning", systemImage: "scope")
                    Label("Approval-gated execution packs", systemImage: "hand.raised")
                    Label("Persistent local memory", systemImage: "externaldrive")
                }

                Section("Not automated yet") {
                    Text("The app does not send email/DMs, publish websites, place orders, spend money, move funds, or trade by itself. Those need separate account integrations and explicit permissions.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
            .navigationTitle("Settings")
        }
    }
}
