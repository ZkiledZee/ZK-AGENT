import SwiftUI

struct MissionsView: View {
    @EnvironmentObject var app: AppState
    @State private var title=""
    @State private var objective=""
    @State private var editing=false
    var passed: [Opportunity] { app.opportunities.filter { !($0.isRejected ?? false) } }
    var rejected: [Opportunity] { app.opportunities.filter { $0.isRejected ?? false } }

    var body: some View {
        NavigationStack {
            List {
                Section("Active mission") {
                    ForEach(app.missions){m in
                        VStack(alignment:.leading,spacing:10){
                            HStack{Text(m.title).font(.headline);Spacer();Text(m.status).font(.caption).foregroundStyle(.secondary)}
                            Text(m.objective).font(.subheadline).foregroundStyle(.secondary)
                            ProgressView(value:m.progress)
                            Button("Edit mission"){title=m.title;objective=m.objective;editing=true}
                        }.padding(.vertical,5)
                    }
                }

                Section("Active V1.5 opportunities") {
                    if passed.isEmpty { Text("No candidates are active yet.").foregroundStyle(.secondary) }
                    ForEach(passed){o in OpportunityRow(opportunity:o) }
                }

                Section("Automatically rejected") {
                    if rejected.isEmpty { Text("Nothing rejected yet.").foregroundStyle(.secondary) }
                    ForEach(rejected){o in OpportunityRow(opportunity:o) }
                }
            }
            .navigationTitle("Missions")
            .sheet(isPresented:$editing){
                NavigationStack{
                    Form{
                        Section("Mission"){TextField("Title",text:$title);TextEditor(text:$objective).frame(minHeight:150)}
                        Section{Button("Save mission"){app.updateMission(title:title.isEmpty ? "Mission":title,objective:objective);editing=false}.disabled(objective.trimmingCharacters(in:.whitespacesAndNewlines).isEmpty)}
                    }.navigationTitle("Edit Mission").toolbar{ToolbarItem(placement:.cancellationAction){Button("Cancel"){editing=false}}}
                }
            }
        }
    }
}

struct OpportunityRow: View {
    let opportunity: Opportunity
    var body: some View {
        NavigationLink { OpportunityDetailView(opportunity:opportunity) } label: {
            VStack(alignment:.leading,spacing:6){
                HStack{Text(opportunity.title).font(.subheadline.bold());Spacer();Text("\(opportunity.score)/100").font(.caption.bold())}
                HStack(spacing:10){Text("Confidence \(opportunity.confidence ?? 0)");Text("Evidence \(opportunity.evidenceQuality ?? 0)")}.font(.caption2).foregroundStyle(.secondary)
                if let items = opportunity.checklist {
                    Text("Checklist \(items.filter(\.isComplete).count)/\(items.count)").font(.caption2).foregroundStyle(.secondary)
                }
                Text(opportunity.status).font(.caption).foregroundStyle(opportunity.isRejected == true ? .orange : .secondary)
                if let reason=opportunity.rejectionReason { Text(reason).font(.caption2).foregroundStyle(.orange) }
            }
        }
    }
}

struct OpportunityDetailView: View {
    @EnvironmentObject var app: AppState
    let opportunity: Opportunity
    var liveOpportunity: Opportunity { app.opportunities.first(where: { $0.id == opportunity.id }) ?? opportunity }
    var body: some View {
        List {
            Section("Decision") {
                LabeledContent("Stage", value: liveOpportunity.stage ?? (liveOpportunity.isRejected == true ? "REJECT" : "ACTIVE"))
                LabeledContent("Score", value:"\(opportunity.score)/100")
                LabeledContent("Speed to cash", value:"\(opportunity.speedToCash ?? 0)/100")
                LabeledContent("Confidence", value:"\(opportunity.confidence ?? 0)/100")
                LabeledContent("Evidence quality", value:"\(opportunity.evidenceQuality ?? 0)/100")
                if let reason=opportunity.rejectionReason { Text(reason).foregroundStyle(.orange) }
            }
            Section("Progress checklist") {
                let items = liveOpportunity.checklist ?? []
                if items.isEmpty { Text("Run this mission again to create a V1.5 checklist.").foregroundStyle(.secondary) }
                ForEach(items) { item in
                    Button { app.toggleChecklist(opportunityID: liveOpportunity.id, itemID: item.id) } label: {
                        HStack(alignment: .top, spacing: 12) {
                            Image(systemName: item.isComplete ? "checkmark.circle.fill" : "circle")
                                .foregroundStyle(item.isComplete ? .green : .secondary)
                            VStack(alignment: .leading, spacing: 3) {
                                Text(item.title).strikethrough(item.isComplete).foregroundStyle(.primary)
                                if !item.detail.isEmpty { Text(item.detail).font(.caption).foregroundStyle(.secondary) }
                            }
                        }
                    }.buttonStyle(.plain)
                }
            }
            Section("Economics") {
                LabeledContent("Startup cost",value:String(format:"£%.0f",opportunity.startupCost))
                LabeledContent("Time to first revenue",value:opportunity.timeToFirstRevenue ?? "Unknown")
                if opportunity.estimatedRevenueHigh > 0 { LabeledContent("Test estimate",value:"£\(Int(opportunity.estimatedRevenueLow))–£\(Int(opportunity.estimatedRevenueHigh))") }
                else { Text("Insufficient evidence for revenue estimate.").foregroundStyle(.secondary) }
            }
            Section("Evidence") { Text(opportunity.evidence); Text(opportunity.whyNow).foregroundStyle(.secondary) }
            Section("Verified facts") {
                let facts=opportunity.verifiedFacts ?? []
                if facts.isEmpty { Text("No verified facts attached.").foregroundStyle(.secondary) }
                ForEach(facts,id:\.self){Text($0)}
            }
            Section("Assumptions / uncertainty") {
                let assumptions=opportunity.assumptions ?? []
                if assumptions.isEmpty { Text("No assumptions declared.").foregroundStyle(.secondary) }
                ForEach(assumptions,id:\.self){Text($0)}
            }
            Section("Next actions") { ForEach(Array(opportunity.nextActions.enumerated()),id:\.offset){i,a in Text("\(i+1). \(a)")} }
            Section("Sources") {
                if opportunity.sources.isEmpty { Text("No live source links attached. Treat as unverified AI analysis.").foregroundStyle(.secondary) }
                ForEach(opportunity.sources){s in if let url=URL(string:s.url){Link(destination:url){Label(s.title,systemImage:"arrow.up.right.square")}}}
            }
        }.navigationTitle(opportunity.title).navigationBarTitleDisplayMode(.inline)
    }
}
