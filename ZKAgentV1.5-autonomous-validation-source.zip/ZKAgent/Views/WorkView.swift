import SwiftUI

struct WorkView: View {
    @EnvironmentObject var app: AppState

    var body: some View {
        NavigationStack {
            List {
                if app.artifacts.isEmpty {
                    VStack(spacing: 14) {
                        Image(systemName: "hammer")
                            .font(.system(size: 36, weight: .semibold))
                            .foregroundStyle(.secondary)
                        Text("No work yet")
                            .font(.headline)
                        Text("Approve a researched opportunity and the AI will create an execution pack here.")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                            .multilineTextAlignment(.center)
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 48)
                    .listRowBackground(Color.clear)
                } else {
                    ForEach(app.artifacts) { artifact in
                        NavigationLink {
                            ArtifactDetailView(artifact: artifact)
                        } label: {
                            VStack(alignment: .leading, spacing: 5) {
                                Text(artifact.title).font(.headline)
                                Text(artifact.kind).font(.caption).foregroundStyle(.secondary)
                                Text(artifact.createdAt, style: .relative).font(.caption2).foregroundStyle(.tertiary)
                            }
                        }
                    }
                }
            }
            .navigationTitle("Work")
        }
    }
}

struct ArtifactDetailView: View {
    let artifact: ActionArtifact

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                Text(artifact.title).font(.title2.bold())
                Text(artifact.content).textSelection(.enabled)
                ShareLink(item: artifact.content) {
                    Label("Share execution pack", systemImage: "square.and.arrow.up")
                }
                .buttonStyle(.borderedProminent)
                .tint(.white)
                .foregroundStyle(.black)
            }
            .padding()
        }
        .navigationTitle("Execution Pack")
        .navigationBarTitleDisplayMode(.inline)
    }
}
