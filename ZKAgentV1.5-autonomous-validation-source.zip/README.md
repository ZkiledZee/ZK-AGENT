# ZK Agent V1.5.0 — Autonomous Validation + Speed-to-Cash

V1.5 changes the pipeline to DISCOVER → VERIFY → EXECUTE and prioritises realistic near-term revenue.

## What changed

- Evidence-first opportunity schema with confidence and evidence-quality scores.
- Four useful stages: Immediate GO (85+), Promising/Verify (70–84), Watchlist (55–69), Reject (<55 or critical flaw).
- Weak evidence creates verification work instead of automatically killing a promising opportunity.
- Speed-to-cash is explicitly scored and services that can sell before software is built receive preference.
- Results focus on the strongest 3–5 opportunities rather than one survivor and a pile of automatic rejections.
- Every opportunity has a persistent interactive checklist that can be ticked off in the app.
- Live-search mode asks the model to research weak assumptions and keeps source links separate from assumptions.
- Free AI-only mode is clearly marked unverified; it cannot pretend a result is current.
- Verified facts and assumptions are shown separately.
- Revenue estimates disappear when the model says evidence is insufficient.
- Mission screen separates active opportunities and genuinely rejected candidates.
- Opportunity details now show score, confidence, evidence quality, startup cost, time to first revenue, verified facts, assumptions, sources, and rejection reason.
- Agent activity now runs through Discover → Verify/Score → Rank → Execute/No-Go → Approval.
- Action packs are shorter and money-focused, with a 60-minute plan, success metric and stop/pivot conditions.
- Same bundle ID: `com.zk.agent` so this installs as an update.

## AI setup

1. Create an OpenRouter API key at https://openrouter.ai/keys
2. Install the IPA.
3. Open Settings → Free AI connection.
4. Paste the key, save to Keychain, then test the connection.
5. Leave Live web search OFF for free-model inference only. Findings without live evidence are treated as unverified.

## Important limitation

V1.5 can research/analyse, score, rank, prepare work, track checklists and remember results locally. It still does not independently send messages, create external accounts, publish to third-party platforms, spend money, move funds, or trade. Those require explicit integrations and permissions in later versions.


## Reliability retained from V1.4.2
- Live and free AI modes stay clearly distinguished without using evidence quality as an automatic rejection switch.
- Free mode can surface promising UNVERIFIED candidates instead of rejecting everything solely because live sources are unavailable.
- Malformed free-model responses no longer mark the API connection OFFLINE.
- Research requests retry once with a simplified strict-JSON repair prompt if the first free model output cannot be decoded.
