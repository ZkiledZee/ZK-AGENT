import Foundation
import SwiftUI

@MainActor
final class AppState: ObservableObject {
    @Published var mode: AgentMode = .assist
    @Published var selectedModel: AgentModel = .freeAuto
    @Published var region: String = "United Kingdom"
    @Published var liveWebSearch: Bool = false
    @Published var state: AgentState = .idle
    @Published var isRunning = false
    @Published var connectionState: AIConnectionState = .notConfigured
    @Published var revenue: Double = 0
    @Published var spend: Double = 0
    @Published var opportunities: [Opportunity] = []
    @Published var missions: [Mission] = []
    @Published var approvals: [ApprovalRequest] = []
    @Published var artifacts: [ActionArtifact] = []
    @Published var activity: [ActivityEvent] = []
    @Published var ledger: [LedgerEntry] = []
    @Published var cycleProgress: Double = 0
    @Published var currentTask = "Ready"
    @Published var currentDetail = "Add a free OpenRouter key, then run a mission."
    @Published var lastError: String? = nil
    @Published var apiKeyInput: String = ""

    private let store = LocalStore()
    private let ai = OpenRouterClient()
    private var runTask: Task<Void, Never>?

    init() {
        load()
        // Always migrate older paid-model selections to the current free router.
        selectedModel = .freeAuto
        apiKeyInput = KeychainStore.read(account: "openrouter_api_key")
        connectionState = apiKeyInput.isEmpty ? .notConfigured : .failed
        if missions.isEmpty {
            missions = [Mission(id: UUID(), title: "Zero-Cost Income", objective: "Find legitimate low-cost or £0-startup opportunities with the fastest realistic path to first revenue.", progress: 0, status: "Ready", createdAt: Date())]
        }
        if activity.isEmpty {
            log("Agent ready", "OpenRouter Free is configured as the default AI route. No fake opportunities are generated.", .idle)
        }
    }

    var activeMission: Mission? { missions.first }
    var hasKey: Bool { !KeychainStore.read(account: "openrouter_api_key").isEmpty }
    var net: Double { revenue - spend }

    func saveAPIKey() {
        let key = apiKeyInput.trimmingCharacters(in: .whitespacesAndNewlines)
        if key.isEmpty {
            KeychainStore.delete(account: "openrouter_api_key")
            connectionState = .notConfigured
        } else {
            KeychainStore.save(key, account: "openrouter_api_key")
            connectionState = .failed
        }
        save()
    }

    func testAI() async {
        let key = KeychainStore.read(account: "openrouter_api_key")
        guard !key.isEmpty else {
            connectionState = .notConfigured
            lastError = "Create a free OpenRouter key and save it first."
            return
        }
        connectionState = .testing
        currentTask = "Testing OpenRouter"
        currentDetail = "Checking the free AI connection without running a mission."
        do {
            let ok = try await ai.validateKey(key)
            connectionState = ok ? .live : .failed
            currentTask = ok ? "Free AI connected" : "Connection failed"
            currentDetail = ok ? "OpenRouter is reachable and your key was accepted." : "The OpenRouter key was rejected."
            log(ok ? "OpenRouter connected" : "OpenRouter rejected", currentDetail, ok ? .success : .warning)
        } catch {
            connectionState = .failed
            lastError = error.localizedDescription
            currentTask = "Connection failed"
            currentDetail = error.localizedDescription
            log("AI offline", error.localizedDescription, .warning)
        }
    }

    func toggleAgent() { isRunning ? stop() : runMission() }

    func runMission() {
        guard !isRunning else { return }
        let key = KeychainStore.read(account: "openrouter_api_key")
        guard !key.isEmpty else {
            lastError = "Add a free OpenRouter API key in Settings first."
            currentTask = "AI setup required"
            currentDetail = "Settings → Free AI connection → Create a free OpenRouter API key"
            state = .warning
            return
        }
        guard let mission = activeMission else { return }
        lastError = nil
        isRunning = true
        cycleProgress = 0.05
        state = .scanning
        currentTask = liveWebSearch ? "Starting AI + live web research" : "Starting free AI research"
        currentDetail = mission.objective
        log("Mission started", "Sending the mission to \(selectedModel.label).", .scanning)
        runTask = Task { [weak self] in await self?.performMission(mission, key: key) }
    }

    func stop() {
        runTask?.cancel()
        runTask = nil
        isRunning = false
        state = .idle
        cycleProgress = 0
        currentTask = "Agent paused"
        currentDetail = "The current request was cancelled locally."
        log("Agent paused", currentDetail, .idle)
    }

    private func performMission(_ mission: Mission, key: String) async {
        state = .researching
        cycleProgress = 0.20
        currentTask = liveWebSearch ? "Stage 1 · researching live evidence" : "Stage 1 · analysing candidates"
        currentDetail = liveWebSearch ? "Searching current evidence and candidate routes." : "Free AI-only mode: ideas will be treated as unverified until evidence exists."
        log("Research stage", currentDetail, .researching)

        do {
            let result = try await ai.researchMission(objective: mission.objective, region: region, model: selectedModel, key: key, liveWebSearch: liveWebSearch)
            if Task.isCancelled { return }

            state = .comparing
            cycleProgress = 0.55
            currentTask = "Stage 2 · verifying & scoring"
            currentDetail = result.summary
            log("Verification stage", "Checking evidence quality, confidence, cost, speed and risk.", .comparing)

            var converted = result.opportunities.map { o -> Opportunity in
                let validSources = o.sources.compactMap { source -> SourceLink? in
                    guard let url = URL(string: source.url), ["http","https"].contains(url.scheme?.lowercased() ?? "") else { return nil }
                    return SourceLink(title: source.title, url: source.url)
                }
                let score = min(100, max(0, o.score))
                let confidence = min(100, max(0, o.confidence))
                let evidenceQuality = min(100, max(0, o.evidence_quality))

                var rejection: String? = nil
                // Live research must meet a strict evidence gate. Free AI-only mode uses a
                // separate planning gate because there are intentionally no current sources.
                let scoreGate = liveWebSearch ? 65 : 45
                let evidenceGate = liveWebSearch ? 45 : 20
                let confidenceGate = liveWebSearch ? 45 : 30
                if score < scoreGate { rejection = "Score below \(scoreGate)/100 \(liveWebSearch ? "evidence" : "planning") threshold." }
                else if liveWebSearch && validSources.isEmpty { rejection = "Live mode returned no usable source evidence." }
                else if evidenceQuality < evidenceGate { rejection = "Evidence quality below \(evidenceGate)/100." }
                else if confidence < confidenceGate { rejection = "Confidence below \(confidenceGate)/100." }

                return Opportunity(
                    id: UUID(), title: o.title, category: o.category, score: score,
                    startupCost: max(0, o.startup_cost),
                    estimatedRevenueLow: max(0, o.estimated_revenue_low),
                    estimatedRevenueHigh: max(o.estimated_revenue_low, o.estimated_revenue_high),
                    evidence: o.evidence, whyNow: o.why_now, nextActions: o.next_actions,
                    sources: validSources,
                    status: rejection == nil ? (liveWebSearch ? "Passed evidence gate" : "Passed planning gate · UNVERIFIED") : "Rejected by V1.4.2 gate",
                    confidence: confidence,
                    evidenceQuality: evidenceQuality,
                    timeToFirstRevenue: o.time_to_first_revenue,
                    assumptions: o.assumptions,
                    verifiedFacts: o.verified_facts,
                    rejectionReason: rejection,
                    isRejected: rejection != nil
                )
            }
            converted.sort { a,b in
                if (a.isRejected ?? false) != (b.isRejected ?? false) { return !(a.isRejected ?? false) }
                return a.score > b.score
            }
            opportunities = converted

            let passed = converted.filter { !($0.isRejected ?? false) }
            let rejected = converted.count - passed.count
            log("Evidence gate complete", "\(passed.count) passed · \(rejected) rejected automatically.", passed.isEmpty ? .warning : .comparing)

            if let idx = missions.firstIndex(where: { $0.id == mission.id }) {
                missions[idx].progress = passed.isEmpty ? 0.55 : 0.78
                missions[idx].status = passed.isEmpty ? "No candidate passed" : "\(passed.count) candidate(s) passed"
            }

            cycleProgress = 0.82
            state = .building
            currentTask = "Stage 3 · selecting next action"
            currentDetail = passed.isEmpty ? "Nothing met the V1.4 evidence threshold. The agent will not fabricate a winner." : "Selecting the strongest candidate that survived the evidence gate."

            if let best = passed.first {
                if mode == .watch {
                    state = .success
                    cycleProgress = 1
                    currentTask = "Research complete"
                    currentDetail = "WATCH mode stopped after evidence filtering. \(passed.count) candidate(s) passed."
                    log("Research complete", "Top survivor: \(best.title) · \(best.score)/100 · confidence \(best.confidence ?? 0)/100.", .success)
                } else {
                    approvals = [ApprovalRequest(
                        id: UUID(), opportunityID: best.id, title: "Prepare verified execution pack",
                        reason: "\(best.title) passed the V1.4 gate at \(best.score)/100 with evidence quality \(best.evidenceQuality ?? 0)/100. Approval creates a verification-first execution pack only.",
                        estimatedCost: 0, risk: "Low", createdAt: Date()
                    )]
                    state = .waitingApproval
                    cycleProgress = 1
                    currentTask = "Approval required"
                    currentDetail = liveWebSearch ? "Review evidence and assumptions before generating the execution pack." : "This passed the AI gate but is still unverified because free web search is off."
                    log("Candidate ready", "\(best.title) survived the evidence gate. Waiting for approval.", .waitingApproval)
                }
            } else {
                approvals = []
                state = .warning
                cycleProgress = 1
                currentTask = "No opportunity passed"
                currentDetail = liveWebSearch ? "No candidate met the strict live evidence threshold." : "No candidate met the free planning threshold. Try a narrower mission or rerun the agent."
                log("No-go decision", "All candidates failed the score/evidence/confidence thresholds.", .warning)
            }
            connectionState = .live
        } catch {
            if Task.isCancelled { return }
            lastError = error.localizedDescription
            // A malformed/free-model completion does not mean the API connection is offline.
            // Keep AI LIVE if the key was already valid so the user can retry immediately.
            connectionState = hasKey ? .live : .notConfigured
            state = .warning
            cycleProgress = 0
            currentTask = "AI response needs retry"
            currentDetail = error.localizedDescription
            log("Mission response failed", error.localizedDescription + " Your previous results were kept; tap Run Live Agent to retry.", .warning)
        }

        isRunning = false
        runTask = nil
        save()
    }

    func approve(_ request: ApprovalRequest) {
        guard let opportunity = opportunities.first(where: { $0.id == request.opportunityID }), let mission = activeMission else { return }
        approvals.removeAll { $0.id == request.id }
        let key = KeychainStore.read(account: "openrouter_api_key")
        guard !key.isEmpty else {
            lastError = "OpenRouter API key missing."
            return
        }

        isRunning = true
        state = .building
        cycleProgress = 0.2
        currentTask = "AI preparing execution pack"
        currentDetail = opportunity.title
        log("Action approved", "Preparing work for \(opportunity.title). No external action is sent automatically.", .building)

        runTask = Task { [weak self] in
            guard let self else { return }
            do {
                let content = try await self.ai.prepareAction(opportunity: opportunity, objective: mission.objective, model: self.selectedModel, key: key)
                if Task.isCancelled { return }
                self.artifacts.insert(ActionArtifact(id: UUID(), opportunityID: opportunity.id, createdAt: Date(), title: opportunity.title, kind: "Execution Pack", content: content), at: 0)
                if let index = self.opportunities.firstIndex(where: { $0.id == opportunity.id }) { self.opportunities[index].status = "Execution pack ready" }
                if let index = self.missions.firstIndex(where: { $0.id == mission.id }) { self.missions[index].progress = 0.9; self.missions[index].status = "Action pack ready" }
                self.state = .success
                self.cycleProgress = 1
                self.currentTask = "Execution pack ready"
                self.currentDetail = "Open Work to review the AI-created plan and copy."
                self.log("Work created", "Execution pack created for \(opportunity.title).", .success)
            } catch {
                self.lastError = error.localizedDescription
                self.state = .warning
                self.currentTask = "Action preparation failed"
                self.currentDetail = error.localizedDescription
                self.log("Action failed", error.localizedDescription, .warning)
            }
            self.isRunning = false
            self.runTask = nil
            self.save()
        }
    }

    func reject(_ request: ApprovalRequest) {
        approvals.removeAll { $0.id == request.id }
        log("Rejected", request.title, .warning)
        save()
    }

    func updateMission(title: String, objective: String) {
        if missions.isEmpty {
            missions = [Mission(id: UUID(), title: title, objective: objective, progress: 0, status: "Ready", createdAt: Date())]
        } else {
            missions[0].title = title
            missions[0].objective = objective
            missions[0].progress = 0
            missions[0].status = "Ready"
        }
        opportunities = []
        approvals = []
        save()
        log("Mission updated", objective, .idle)
    }

    func addRevenue(_ amount: Double, note: String) {
        guard amount > 0 else { return }
        revenue += amount
        ledger.insert(LedgerEntry(id: UUID(), timestamp: Date(), type: "Revenue", amount: amount, note: note), at: 0)
        log("Revenue recorded", String(format: "£%.2f — %@", amount, note), .success)
        save()
    }

    func addExpense(_ amount: Double, note: String) {
        guard amount > 0 else { return }
        spend += amount
        ledger.insert(LedgerEntry(id: UUID(), timestamp: Date(), type: "Expense", amount: -amount, note: note), at: 0)
        save()
    }

    private func log(_ title: String, _ detail: String, _ eventState: AgentState) {
        activity.insert(ActivityEvent(title: title, detail: detail, state: eventState), at: 0)
        if activity.count > 100 { activity = Array(activity.prefix(100)) }
    }

    private func load() {
        guard let snapshot = store.load() else { return }
        mode = snapshot.mode
        selectedModel = snapshot.selectedModel
        region = snapshot.region
        liveWebSearch = snapshot.liveWebSearch ?? false
        revenue = snapshot.revenue
        spend = snapshot.spend
        opportunities = snapshot.opportunities
        missions = snapshot.missions
        approvals = snapshot.approvals
        artifacts = snapshot.artifacts
        activity = snapshot.activity
        ledger = snapshot.ledger
    }

    func save() {
        store.save(Snapshot(
            mode: mode,
            selectedModel: selectedModel,
            region: region,
            liveWebSearch: liveWebSearch,
            revenue: revenue,
            spend: spend,
            opportunities: opportunities,
            missions: missions,
            approvals: approvals,
            artifacts: artifacts,
            activity: activity,
            ledger: ledger
        ))
    }
}
