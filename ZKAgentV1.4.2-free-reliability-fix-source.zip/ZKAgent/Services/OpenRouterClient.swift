import Foundation

enum OpenRouterClientError: LocalizedError {
    case invalidKey, badResponse, api(String), noText, invalidJSON(String)
    var errorDescription: String? {
        switch self {
        case .invalidKey: return "The OpenRouter API key is empty or invalid."
        case .badResponse: return "OpenRouter returned an invalid response."
        case .api(let message): return message
        case .noText: return "The AI returned no usable result."
        case .invalidJSON(let message): return "Could not read the AI result: \(message)"
        }
    }
}

struct OpenRouterClient {
    private let base = URL(string: "https://openrouter.ai/api/v1")!

    func validateKey(_ key: String) async throws -> Bool {
        guard !key.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { throw OpenRouterClientError.invalidKey }
        var req = URLRequest(url: base.appendingPathComponent("models"))
        req.setValue("Bearer \(key)", forHTTPHeaderField: "Authorization")
        req.setValue("ZK Agent", forHTTPHeaderField: "X-Title")
        let (_, response) = try await URLSession.shared.data(for: req)
        guard let http = response as? HTTPURLResponse else { throw OpenRouterClientError.badResponse }
        return (200..<300).contains(http.statusCode)
    }

    func researchMission(objective: String, region: String, model: AgentModel, key: String, liveWebSearch: Bool) async throws -> AgentResearchResult {
        let system = """
        You are ZK Agent V1.4, an evidence-first opportunity researcher. Your job is not to brainstorm attractive ideas; your job is to filter aggressively for practical, legitimate routes to first revenue.

        Score each candidate on: probability of first revenue, time to first revenue, startup cost, competition, current demand evidence, automation potential, evidence quality, platform/legal risk, and realistic net-profit potential.

        CRITICAL RULES:
        - Never invent buyers, jobs, demand, prices, platform rules, source URLs, completed actions, or verification.
        - A score above 65 must be justified by evidence. If live web search is OFF, evidence_quality should usually be <=45 and confidence should reflect uncertainty.
        - If sources are absent, say what is assumed. Do not call it verified or live.
        - Revenue ranges are test estimates, not promises. If evidence is weak, use 0/0 instead of a flashy estimate.
        - Prefer a narrow, executable opportunity over generic categories such as "freelancing" or "dropshipping".
        - Avoid gambling, deceptive spam, speculative trading, illegal activity, regulated goods, misleading claims, fake portfolios, fake reviews, or impersonation.
        - verified_facts must contain only facts supported by supplied sources or stable platform facts you are highly confident about. assumptions must expose uncertainty.

        Return JSON only in exactly this shape:
        {
          "summary":"string",
          "opportunities":[
            {
              "title":"specific opportunity",
              "category":"string",
              "score":0,
              "confidence":0,
              "evidence_quality":0,
              "startup_cost":0,
              "estimated_revenue_low":0,
              "estimated_revenue_high":0,
              "time_to_first_revenue":"string",
              "evidence":"string",
              "why_now":"string",
              "verified_facts":["string"],
              "assumptions":["string"],
              "next_actions":["string"],
              "sources":[{"title":"string","url":"https://..."}]
            }
          ]
        }
        Return 4 to 7 candidates. It is acceptable for every candidate to score below 65.
        """

        let modeText = liveWebSearch
            ? "Live web search is enabled. Use it to verify current facts. Source links must be real returned sources."
            : "Free AI-only mode is enabled. No live web verification is available. Empty sources are expected; lower evidence quality/confidence accordingly."
        let user = "Mission: \(objective)\nRegion/context: \(region)\n\(modeText)\nFind, challenge, and score the strongest candidates."

        var body: [String: Any] = [
            "model": model.rawValue,
            "messages": [["role":"system","content":system],["role":"user","content":user]],
            "temperature": 0.15,
            "max_tokens": 6500,
            "response_format": ["type":"json_object"]
        ]
        if liveWebSearch {
            body["tools"] = [["type":"openrouter:web_search"]]
            body["tool_choice"] = "auto"
        }
        do {
            let data = try await postChat(body: body, key: key)
            let text = try extractMessageText(data)
            return try decodeResearchResult(text)
        } catch OpenRouterClientError.noText {
            return try await retryResearchJSON(objective: objective, region: region, model: model, key: key, liveWebSearch: liveWebSearch)
        } catch OpenRouterClientError.invalidJSON {
            return try await retryResearchJSON(objective: objective, region: region, model: model, key: key, liveWebSearch: liveWebSearch)
        } catch DecodingError.dataCorrupted {
            return try await retryResearchJSON(objective: objective, region: region, model: model, key: key, liveWebSearch: liveWebSearch)
        }
    }


    private func retryResearchJSON(objective: String, region: String, model: AgentModel, key: String, liveWebSearch: Bool) async throws -> AgentResearchResult {
        let prompt = """
        Return STRICT JSON only. No markdown, no code fences, no commentary.
        Mission: \(objective)
        Region: \(region)
        Live web verification: \(liveWebSearch ? "ON" : "OFF")

        Produce exactly this schema with 4-6 practical candidates:
        {"summary":"...","opportunities":[{"title":"...","category":"...","score":0,"confidence":0,"evidence_quality":0,"startup_cost":0,"estimated_revenue_low":0,"estimated_revenue_high":0,"time_to_first_revenue":"...","evidence":"...","why_now":"...","verified_facts":[],"assumptions":[],"next_actions":[],"sources":[]}]}

        Rules: numeric fields must be JSON numbers, all arrays must exist, and sources must be [] when you do not have verified URLs. Do not invent live evidence.
        """
        let repairBody: [String: Any] = [
            "model": model.rawValue,
            "messages": [["role":"user","content":prompt]],
            "temperature": 0.0,
            "max_tokens": 5000,
            "response_format": ["type":"json_object"]
        ]
        let data = try await postChat(body: repairBody, key: key)
        let text = try extractMessageText(data)
        return try decodeResearchResult(text)
    }

    private func decodeResearchResult(_ text: String) throws -> AgentResearchResult {
        let cleaned = extractJSONObject(stripCodeFence(text))
        do {
            return try JSONDecoder().decode(AgentResearchResult.self, from: Data(cleaned.utf8))
        } catch {
            throw OpenRouterClientError.invalidJSON(error.localizedDescription)
        }
    }

    private func extractJSONObject(_ text: String) -> String {
        let value = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard let first = value.firstIndex(of: "{"), let last = value.lastIndex(of: "}"), first <= last else { return value }
        return String(value[first...last])
    }

    func prepareAction(opportunity: Opportunity, objective: String, model: AgentModel, key: String) async throws -> String {
        let sourceText = opportunity.sources.isEmpty ? "No verified live sources attached." : opportunity.sources.map { "- \($0.title): \($0.url)" }.joined(separator:"\n")
        let facts = (opportunity.verifiedFacts ?? []).map { "- \($0)" }.joined(separator:"\n")
        let assumptions = (opportunity.assumptions ?? []).map { "- \($0)" }.joined(separator:"\n")
        let actions = opportunity.nextActions.enumerated().map { "\($0.offset+1). \($0.element)" }.joined(separator:"\n")
        let prompt = """
        You are the execution-planning stage of ZK Agent V1.4.
        Mission: \(objective)
        Selected opportunity: \(opportunity.title)
        Score: \(opportunity.score)/100; confidence: \(opportunity.confidence ?? 0)/100; evidence quality: \(opportunity.evidenceQuality ?? 0)/100.
        Evidence: \(opportunity.evidence)
        Why now: \(opportunity.whyNow)
        Verified facts:\n\(facts.isEmpty ? "- None attached" : facts)
        Assumptions:\n\(assumptions.isEmpty ? "- None declared" : assumptions)
        Sources:\n\(sourceText)
        Existing next actions:\n\(actions)

        Create an execution pack that starts with verification, not blind execution. Include:
        1. GO / NO-GO gate and what must be verified before acting.
        2. First 60-minute plan.
        3. Exact verification checklist.
        4. Draft outreach/listing/sales copy only when relevant.
        5. Success metric for the first test.
        6. Stop condition and pivot trigger.
        7. Which next steps ZK Agent could automate once integrations exist.

        Do not claim external actions happened. Do not spend money, send messages, create accounts, place trades, or move funds.
        """
        let body: [String: Any] = ["model":model.rawValue,"messages":[["role":"user","content":prompt]],"temperature":0.25,"max_tokens":4200]
        let data = try await postChat(body: body, key: key)
        return try extractMessageText(data)
    }

    private func postChat(body: [String: Any], key: String) async throws -> Data {
        guard !key.isEmpty else { throw OpenRouterClientError.invalidKey }
        var req = URLRequest(url: base.appendingPathComponent("chat/completions"))
        req.httpMethod = "POST"
        req.setValue("Bearer \(key)", forHTTPHeaderField:"Authorization")
        req.setValue("application/json", forHTTPHeaderField:"Content-Type")
        req.setValue("ZK Agent", forHTTPHeaderField:"X-Title")
        req.httpBody = try JSONSerialization.data(withJSONObject: body)
        req.timeoutInterval = 150
        let (data,response) = try await URLSession.shared.data(for:req)
        guard let http = response as? HTTPURLResponse else { throw OpenRouterClientError.badResponse }
        if !(200..<300).contains(http.statusCode) {
            if let root = try? JSONSerialization.jsonObject(with:data) as? [String:Any], let e=root["error"] as? [String:Any], let m=e["message"] as? String { throw OpenRouterClientError.api(m) }
            throw OpenRouterClientError.api("OpenRouter request failed (HTTP \(http.statusCode)).")
        }
        return data
    }

    private func extractMessageText(_ data: Data) throws -> String {
        guard let root=try JSONSerialization.jsonObject(with:data) as? [String:Any], let choices=root["choices"] as? [[String:Any]], let first=choices.first, let message=first["message"] as? [String:Any] else { throw OpenRouterClientError.badResponse }
        if let content=message["content"] as? String, !content.trimmingCharacters(in:.whitespacesAndNewlines).isEmpty { return stripCodeFence(content) }
        if let content=message["content"] as? [[String:Any]] {
            let joined=content.compactMap { item -> String? in
                if let text = item["text"] as? String { return text }
                if let text = item["content"] as? String { return text }
                return nil
            }.joined(separator:"\n")
            if !joined.isEmpty { return stripCodeFence(joined) }
        }
        if let refusal = message["refusal"] as? String, !refusal.isEmpty { throw OpenRouterClientError.api(refusal) }
        throw OpenRouterClientError.noText
    }

    private func stripCodeFence(_ text:String)->String {
        var value=text.trimmingCharacters(in:.whitespacesAndNewlines)
        if value.hasPrefix("```json") { value.removeFirst(7) } else if value.hasPrefix("```") { value.removeFirst(3) }
        if value.hasSuffix("```") { value.removeLast(3) }
        return value.trimmingCharacters(in:.whitespacesAndNewlines)
    }
}
