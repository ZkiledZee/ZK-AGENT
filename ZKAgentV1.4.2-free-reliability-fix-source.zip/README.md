# ZK Agent V1.4.0 — Evidence Gate

V1.4 upgrades the live AI build from a general planner into a stricter evidence-first agent pipeline.

## What changed

- Evidence-first opportunity schema with confidence and evidence-quality scores.
- Automatic V1.4 gate rejects candidates below 65/100, weak evidence, or weak confidence.
- Live-search mode also rejects a supposedly live candidate if it has no usable source URL.
- Free AI-only mode is clearly marked unverified; it cannot pretend a result is current.
- Verified facts and assumptions are shown separately.
- Revenue estimates disappear when the model says evidence is insufficient.
- Mission screen now separates PASSED and AUTOMATICALLY REJECTED candidates.
- Opportunity details now show score, confidence, evidence quality, startup cost, time to first revenue, verified facts, assumptions, sources, and rejection reason.
- Agent activity now runs through Research → Verify/Score → Evidence Gate → Select/No-Go → Approval.
- Execution packs start with a GO/NO-GO verification gate and include pivot/stop conditions.
- Same bundle ID: `com.zk.agent` so this installs as an update.

## AI setup

1. Create an OpenRouter API key at https://openrouter.ai/keys
2. Install the IPA.
3. Open Settings → Free AI connection.
4. Paste the key, save to Keychain, then test the connection.
5. Leave Live web search OFF for free-model inference only. Findings without live evidence are treated as unverified.

## Important limitation

V1.4 can research/analyse, score, filter, prepare work and remember results locally. It still does not independently send messages, create external accounts, publish to third-party platforms, spend money, move funds, or trade. Those require explicit integrations and permissions in later versions.


## V1.4.2 reliability fix
- Separate strict live-evidence gate from free AI-only planning gate.
- Free mode can surface promising UNVERIFIED candidates instead of rejecting everything solely because live sources are unavailable.
- Malformed free-model responses no longer mark the API connection OFFLINE.
- Research requests retry once with a simplified strict-JSON repair prompt if the first free model output cannot be decoded.
