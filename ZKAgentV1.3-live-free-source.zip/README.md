# ZK Agent v1.3.0 — OpenRouter Free

This build switches the AI layer from paid OpenAI API usage to **OpenRouter Free** by default.

## Setup
1. Build/install the IPA as usual.
2. In ZK Agent open **Settings → Free AI connection**.
3. Tap **Create a free OpenRouter API key** and create/copy a key.
4. Paste it into the app, tap **Save key to iPhone Keychain**, then **Test free AI connection**.
5. Leave **Live web search OFF** for the free route.
6. Set the mission and tap **Run Agent**.

## Free mode
The app uses `openrouter/free`, which routes requests to currently available free models. Free mode can reason, rank ideas, plan work, draft copy, and create execution packs. It does **not** pretend its answers are live/current and does not fabricate source URLs.

## Optional live web search
The **Live web search** switch uses OpenRouter's web-search tool. That tool is not fully free, so it is OFF by default. Keep it OFF if you want zero model/search charges.

## Safety
No email/DM sending, publishing, payments, wallet transfers, trading, or purchases happen automatically. Those require separate integrations and approvals.

Bundle ID: `com.zk.agent`
Version: `1.3.0` (build 6)
