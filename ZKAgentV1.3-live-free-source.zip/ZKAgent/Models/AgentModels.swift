import Foundation

enum AgentMode: String, Codable, CaseIterable { case watch = "WATCH", assist = "ASSIST", autopilot = "AUTOPILOT" }
enum AgentState: String, Codable { case idle, scanning, researching, comparing, building, waitingApproval, success, warning }
enum AIConnectionState: String { case notConfigured = "SETUP", testing = "TESTING", live = "AI LIVE", failed = "OFFLINE" }

enum AgentModel: String, Codable, CaseIterable, Identifiable {
    case freeAuto = "openrouter/free"
    // Legacy cases are kept so an older saved state can still decode after updating.
    case luna = "gpt-5.6-luna"
    case terra = "gpt-5.6-terra"
    case sol = "gpt-5.6-sol"

    var id: String { rawValue }
    static var selectable: [AgentModel] { [.freeAuto] }
    var label: String {
        switch self {
        case .freeAuto: return "OpenRouter Free · auto"
        case .luna, .terra, .sol: return "Legacy model"
        }
    }
}

struct ActivityEvent: Identifiable, Codable, Hashable {
    let id: UUID
    let timestamp: Date
    let title: String
    let detail: String
    let state: AgentState
    init(id: UUID = UUID(), timestamp: Date = Date(), title: String, detail: String, state: AgentState) {
        self.id=id; self.timestamp=timestamp; self.title=title; self.detail=detail; self.state=state
    }
}

struct SourceLink: Identifiable, Codable, Hashable {
    let id: UUID
    var title: String
    var url: String
    init(id: UUID = UUID(), title: String, url: String) { self.id=id; self.title=title; self.url=url }
}

struct Opportunity: Identifiable, Codable, Hashable {
    let id: UUID
    var title: String
    var category: String
    var score: Int
    var startupCost: Double
    var estimatedRevenueLow: Double
    var estimatedRevenueHigh: Double
    var evidence: String
    var whyNow: String
    var nextActions: [String]
    var sources: [SourceLink]
    var status: String
}

struct Mission: Identifiable, Codable, Hashable {
    let id: UUID
    var title: String
    var objective: String
    var progress: Double
    var status: String
    var createdAt: Date
}

struct ApprovalRequest: Identifiable, Codable, Hashable {
    let id: UUID
    var opportunityID: UUID
    var title: String
    var reason: String
    var estimatedCost: Double
    var risk: String
    var createdAt: Date
}

struct ActionArtifact: Identifiable, Codable, Hashable {
    let id: UUID
    let opportunityID: UUID
    let createdAt: Date
    let title: String
    let kind: String
    let content: String
}

struct LedgerEntry: Identifiable, Codable, Hashable {
    let id: UUID
    let timestamp: Date
    let type: String
    let amount: Double
    let note: String
}

struct AgentResearchResult: Codable {
    let summary: String
    let opportunities: [AIOpportunity]
}

struct AIOpportunity: Codable {
    let title: String
    let category: String
    let score: Int
    let startup_cost: Double
    let estimated_revenue_low: Double
    let estimated_revenue_high: Double
    let evidence: String
    let why_now: String
    let next_actions: [String]
    let sources: [AISource]
}

struct AISource: Codable { let title: String; let url: String }
