import Foundation
import SwiftUI

@MainActor
final class AppState: ObservableObject {
    @Published var mode: AgentMode = .assist
    @Published var selectedModel: AgentModel = .freeAuto
    @Published var region: String = "United Kingdom"
    @Published var liveWebSearch: Bool = false
    @Published var state: AgentState = .idle
    @Published var isRunning = false
    @Published var connectionState: AIConnectionState = .notConfigured
    @Published var revenue: Double = 0
    @Published var spend: Double = 0
    @Published var opportunities: [Opportunity] = []
    @Published var missions: [Mission] = []
    @Published var approvals: [ApprovalRequest] = []
    @Published var artifacts: [ActionArtifact] = []
    @Published var activity: [ActivityEvent] = []
    @Published var ledger: [LedgerEntry] = []
    @Published var cycleProgress: Double = 0
    @Published var currentTask = "Ready"
    @Published var currentDetail = "Add a free OpenRouter key, then run a mission."
    @Published var lastError: String? = nil
    @Published var apiKeyInput: String = ""

    private let store = LocalStore()
    private let ai = OpenRouterClient()
    private var runTask: Task<Void, Never>?

    init() {
        load()
        // Always migrate older paid-model selections to the current free router.
        selectedModel = .freeAuto
        apiKeyInput = KeychainStore.read(account: "openrouter_api_key")
        connectionState = apiKeyInput.isEmpty ? .notConfigured : .failed
        if missions.isEmpty {
            missions = [Mission(id: UUID(), title: "Zero-Cost Income", objective: "Find legitimate low-cost or £0-startup opportunities with the fastest realistic path to first revenue.", progress: 0, status: "Ready", createdAt: Date())]
        }
        if activity.isEmpty {
            log("Agent ready", "OpenRouter Free is configured as the default AI route. No fake opportunities are generated.", .idle)
        }
    }

    var activeMission: Mission? { missions.first }
    var hasKey: Bool { !KeychainStore.read(account: "openrouter_api_key").isEmpty }
    var net: Double { revenue - spend }

    func saveAPIKey() {
        let key = apiKeyInput.trimmingCharacters(in: .whitespacesAndNewlines)
        if key.isEmpty {
            KeychainStore.delete(account: "openrouter_api_key")
            connectionState = .notConfigured
        } else {
            KeychainStore.save(key, account: "openrouter_api_key")
            connectionState = .failed
        }
        save()
    }

    func testAI() async {
        let key = KeychainStore.read(account: "openrouter_api_key")
        guard !key.isEmpty else {
            connectionState = .notConfigured
            lastError = "Create a free OpenRouter key and save it first."
            return
        }
        connectionState = .testing
        currentTask = "Testing OpenRouter"
        currentDetail = "Checking the free AI connection without running a mission."
        do {
            let ok = try await ai.validateKey(key)
            connectionState = ok ? .live : .failed
            currentTask = ok ? "Free AI connected" : "Connection failed"
            currentDetail = ok ? "OpenRouter is reachable and your key was accepted." : "The OpenRouter key was rejected."
            log(ok ? "OpenRouter connected" : "OpenRouter rejected", currentDetail, ok ? .success : .warning)
        } catch {
            connectionState = .failed
            lastError = error.localizedDescription
            currentTask = "Connection failed"
            currentDetail = error.localizedDescription
            log("AI offline", error.localizedDescription, .warning)
        }
    }

    func toggleAgent() { isRunning ? stop() : runMission() }

    func runMission() {
        guard !isRunning else { return }
        let key = KeychainStore.read(account: "openrouter_api_key")
        guard !key.isEmpty else {
            lastError = "Add a free OpenRouter API key in Settings first."
            currentTask = "AI setup required"
            currentDetail = "Settings → Free AI connection → Create a free OpenRouter API key"
            state = .warning
            return
        }
        guard let mission = activeMission else { return }
        lastError = nil
        isRunning = true
        cycleProgress = 0.05
        state = .scanning
        currentTask = liveWebSearch ? "Starting AI + live web research" : "Starting free AI research"
        currentDetail = mission.objective
        log("Mission started", "Sending the mission to \(selectedModel.label).", .scanning)
        runTask = Task { [weak self] in await self?.performMission(mission, key: key) }
    }

    func stop() {
        runTask?.cancel()
        runTask = nil
        isRunning = false
        state = .idle
        cycleProgress = 0
        currentTask = "Agent paused"
        currentDetail = "The current request was cancelled locally."
        log("Agent paused", currentDetail, .idle)
    }

    private func performMission(_ mission: Mission, key: String) async {
        state = .researching
        cycleProgress = 0.28
        currentTask = liveWebSearch ? "AI researching current web results" : "Free AI analysing opportunities"
        currentDetail = liveWebSearch ? "Web search is enabled; source links may be returned." : "No paid web-search tool is enabled. Findings are analysis, not verified live opportunities."
        log(liveWebSearch ? "Live research" : "Free AI research", currentDetail, .researching)

        do {
            let result = try await ai.researchMission(objective: mission.objective, region: region, model: selectedModel, key: key, liveWebSearch: liveWebSearch)
            if Task.isCancelled { return }

            state = .comparing
            cycleProgress = 0.74
            currentTask = "Scoring findings"
            currentDetail = result.summary
            log("Research returned", result.summary, .comparing)

            let converted = result.opportunities.map { o in
                Opportunity(
                    id: UUID(),
                    title: o.title,
                    category: o.category,
                    score: min(100, max(0, o.score)),
                    startupCost: max(0, o.startup_cost),
                    estimatedRevenueLow: max(0, o.estimated_revenue_low),
                    estimatedRevenueHigh: max(o.estimated_revenue_low, o.estimated_revenue_high),
                    evidence: o.evidence,
                    whyNow: o.why_now,
                    nextActions: o.next_actions,
                    sources: o.sources.compactMap { source in
                        guard URL(string: source.url) != nil else { return nil }
                        return SourceLink(title: source.title, url: source.url)
                    },
                    status: liveWebSearch ? "Web-researched" : "AI analysis"
                )
            }.sorted { $0.score > $1.score }

            opportunities = converted
            if let idx = missions.firstIndex(where: { $0.id == mission.id }) {
                missions[idx].progress = 0.7
                missions[idx].status = liveWebSearch ? "Web researched" : "AI analysed"
            }

            cycleProgress = 0.92
            state = .building
            currentTask = "Preparing next decision"
            currentDetail = "Choosing the strongest candidate for an execution pack."

            if let best = converted.first {
                if mode == .watch {
                    state = .success
                    cycleProgress = 1
                    currentTask = "Research complete"
                    currentDetail = "WATCH mode saved \(converted.count) opportunities and stopped before action preparation."
                    log("Research complete", "Top result: \(best.title) (\(best.score)/100).", .success)
                } else {
                    approvals = [ApprovalRequest(
                        id: UUID(),
                        opportunityID: best.id,
                        title: "Prepare execution pack",
                        reason: "\(best.title) scored \(best.score)/100. Approval lets the AI create the plan/copy/checklist; it does not send or spend.",
                        estimatedCost: 0,
                        risk: "Low",
                        createdAt: Date()
                    )]
                    state = .waitingApproval
                    cycleProgress = 1
                    currentTask = "Approval required"
                    currentDetail = liveWebSearch ? "Review the attached sources before preparing the work pack." : "Free mode has no verified live sources; verify the idea before acting on it."
                    log("Approval required", "Prepare the next step for \(best.title).", .waitingApproval)
                }
            } else {
                state = .warning
                currentTask = "No usable opportunities"
                currentDetail = "The AI returned no structured opportunities."
            }
            connectionState = .live
        } catch {
            if Task.isCancelled { return }
            lastError = error.localizedDescription
            connectionState = .failed
            state = .warning
            cycleProgress = 0
            currentTask = "AI request failed"
            currentDetail = error.localizedDescription
            log("Mission failed", error.localizedDescription, .warning)
        }

        isRunning = false
        runTask = nil
        save()
    }

    func approve(_ request: ApprovalRequest) {
        guard let opportunity = opportunities.first(where: { $0.id == request.opportunityID }), let mission = activeMission else { return }
        approvals.removeAll { $0.id == request.id }
        let key = KeychainStore.read(account: "openrouter_api_key")
        guard !key.isEmpty else {
            lastError = "OpenRouter API key missing."
            return
        }

        isRunning = true
        state = .building
        cycleProgress = 0.2
        currentTask = "AI preparing execution pack"
        currentDetail = opportunity.title
        log("Action approved", "Preparing work for \(opportunity.title). No external action is sent automatically.", .building)

        runTask = Task { [weak self] in
            guard let self else { return }
            do {
                let content = try await self.ai.prepareAction(opportunity: opportunity, objective: mission.objective, model: self.selectedModel, key: key)
                if Task.isCancelled { return }
                self.artifacts.insert(ActionArtifact(id: UUID(), opportunityID: opportunity.id, createdAt: Date(), title: opportunity.title, kind: "Execution Pack", content: content), at: 0)
                if let index = self.opportunities.firstIndex(where: { $0.id == opportunity.id }) { self.opportunities[index].status = "Execution pack ready" }
                if let index = self.missions.firstIndex(where: { $0.id == mission.id }) { self.missions[index].progress = 0.9; self.missions[index].status = "Action pack ready" }
                self.state = .success
                self.cycleProgress = 1
                self.currentTask = "Execution pack ready"
                self.currentDetail = "Open Work to review the AI-created plan and copy."
                self.log("Work created", "Execution pack created for \(opportunity.title).", .success)
            } catch {
                self.lastError = error.localizedDescription
                self.state = .warning
                self.currentTask = "Action preparation failed"
                self.currentDetail = error.localizedDescription
                self.log("Action failed", error.localizedDescription, .warning)
            }
            self.isRunning = false
            self.runTask = nil
            self.save()
        }
    }

    func reject(_ request: ApprovalRequest) {
        approvals.removeAll { $0.id == request.id }
        log("Rejected", request.title, .warning)
        save()
    }

    func updateMission(title: String, objective: String) {
        if missions.isEmpty {
            missions = [Mission(id: UUID(), title: title, objective: objective, progress: 0, status: "Ready", createdAt: Date())]
        } else {
            missions[0].title = title
            missions[0].objective = objective
            missions[0].progress = 0
            missions[0].status = "Ready"
        }
        opportunities = []
        approvals = []
        save()
        log("Mission updated", objective, .idle)
    }

    func addRevenue(_ amount: Double, note: String) {
        guard amount > 0 else { return }
        revenue += amount
        ledger.insert(LedgerEntry(id: UUID(), timestamp: Date(), type: "Revenue", amount: amount, note: note), at: 0)
        log("Revenue recorded", String(format: "£%.2f — %@", amount, note), .success)
        save()
    }

    func addExpense(_ amount: Double, note: String) {
        guard amount > 0 else { return }
        spend += amount
        ledger.insert(LedgerEntry(id: UUID(), timestamp: Date(), type: "Expense", amount: -amount, note: note), at: 0)
        save()
    }

    private func log(_ title: String, _ detail: String, _ eventState: AgentState) {
        activity.insert(ActivityEvent(title: title, detail: detail, state: eventState), at: 0)
        if activity.count > 100 { activity = Array(activity.prefix(100)) }
    }

    private func load() {
        guard let snapshot = store.load() else { return }
        mode = snapshot.mode
        selectedModel = snapshot.selectedModel
        region = snapshot.region
        liveWebSearch = snapshot.liveWebSearch ?? false
        revenue = snapshot.revenue
        spend = snapshot.spend
        opportunities = snapshot.opportunities
        missions = snapshot.missions
        approvals = snapshot.approvals
        artifacts = snapshot.artifacts
        activity = snapshot.activity
        ledger = snapshot.ledger
    }

    func save() {
        store.save(Snapshot(
            mode: mode,
            selectedModel: selectedModel,
            region: region,
            liveWebSearch: liveWebSearch,
            revenue: revenue,
            spend: spend,
            opportunities: opportunities,
            missions: missions,
            approvals: approvals,
            artifacts: artifacts,
            activity: activity,
            ledger: ledger
        ))
    }
}
