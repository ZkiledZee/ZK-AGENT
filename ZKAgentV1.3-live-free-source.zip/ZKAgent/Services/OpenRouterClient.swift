import Foundation

enum OpenRouterClientError: LocalizedError {
    case invalidKey, badResponse, api(String), noText, invalidJSON(String)
    var errorDescription: String? {
        switch self {
        case .invalidKey: return "The OpenRouter API key is empty or invalid."
        case .badResponse: return "OpenRouter returned an invalid response."
        case .api(let message): return message
        case .noText: return "The AI returned no usable result."
        case .invalidJSON(let message): return "Could not read the AI result: \(message)"
        }
    }
}

struct OpenRouterClient {
    private let base = URL(string: "https://openrouter.ai/api/v1")!

    func validateKey(_ key: String) async throws -> Bool {
        guard !key.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { throw OpenRouterClientError.invalidKey }
        var req = URLRequest(url: base.appendingPathComponent("models"))
        req.setValue("Bearer \(key)", forHTTPHeaderField: "Authorization")
        req.setValue("ZK Agent", forHTTPHeaderField: "X-Title")
        let (_, response) = try await URLSession.shared.data(for: req)
        guard let http = response as? HTTPURLResponse else { throw OpenRouterClientError.badResponse }
        return (200..<300).contains(http.statusCode)
    }

    func researchMission(objective: String, region: String, model: AgentModel, key: String, liveWebSearch: Bool) async throws -> AgentResearchResult {
        let system = """
        You are ZK Agent, an evidence-conscious income opportunity researcher. Find legitimate, practical ways a single person could pursue revenue quickly. Prefer low startup cost, short time to first revenue, simple execution, and opportunities that can be partly automated by software or AI.

        Never invent buyers, job requests, prices, demand, source URLs, or completed actions. Do not recommend gambling, deceptive spam, high-risk speculative trading, illegal activity, regulated goods, or misleading claims. Revenue ranges must be rough estimates rather than guarantees.

        If live web search is unavailable, explicitly treat the result as AI analysis based on model knowledge and return an empty sources array rather than fabricating citations. If live search is available, only include source URLs actually supplied by search results.

        Return JSON only, matching this exact shape:
        {
          "summary":"string",
          "opportunities":[
            {
              "title":"string",
              "category":"string",
              "score":0,
              "startup_cost":0,
              "estimated_revenue_low":0,
              "estimated_revenue_high":0,
              "evidence":"string",
              "why_now":"string",
              "next_actions":["string"],
              "sources":[{"title":"string","url":"https://..."}]
            }
          ]
        }
        Return 3 to 5 opportunities. Keep next_actions between 2 and 6 items.
        """

        let freshness = liveWebSearch
            ? "Live web search is enabled. Use it where it materially improves the answer and cite only real returned sources."
            : "Free mode is enabled with no paid web-search tool. Do not claim the findings are live/current and do not fabricate source URLs."
        let user = "Mission: \(objective)\nRegion/context: \(region)\n\(freshness)\nFind the strongest practical opportunities and concrete next actions."

        var body: [String: Any] = [
            "model": model.rawValue,
            "messages": [
                ["role": "system", "content": system],
                ["role": "user", "content": user]
            ],
            "temperature": 0.3,
            "max_tokens": 5000,
            "response_format": ["type": "json_object"]
        ]

        if liveWebSearch {
            body["tools"] = [["type": "openrouter:web_search"]]
            body["tool_choice"] = "auto"
        }

        let data = try await postChat(body: body, key: key)
        let text = try extractMessageText(data)
        do {
            return try JSONDecoder().decode(AgentResearchResult.self, from: Data(text.utf8))
        } catch {
            throw OpenRouterClientError.invalidJSON(error.localizedDescription)
        }
    }

    func prepareAction(opportunity: Opportunity, objective: String, model: AgentModel, key: String) async throws -> String {
        let sourceText = opportunity.sources.isEmpty
            ? "No verified live sources were attached to this opportunity."
            : opportunity.sources.map { "- \($0.title): \($0.url)" }.joined(separator: "\n")
        let actions = opportunity.nextActions.enumerated().map { "\($0.offset + 1). \($0.element)" }.joined(separator: "\n")
        let prompt = """
        Mission: \(objective)
        Selected opportunity: \(opportunity.title)
        Evidence/analysis: \(opportunity.evidence)
        Why now: \(opportunity.whyNow)
        Sources:
        \(sourceText)
        Existing next actions:
        \(actions)

        Create a practical execution pack. Include:
        1. First 60-minute plan.
        2. Exact verification checklist.
        3. Outreach message, listing copy, or sales script when relevant.
        4. What must NOT be claimed.
        5. Success metric for the first test.
        6. Clear stop condition.

        Do not claim any external action has already happened. Do not send messages, spend money, place trades, or move funds. This is preparation only.
        """
        let body: [String: Any] = [
            "model": model.rawValue,
            "messages": [["role": "user", "content": prompt]],
            "temperature": 0.35,
            "max_tokens": 3500
        ]
        let data = try await postChat(body: body, key: key)
        return try extractMessageText(data)
    }

    private func postChat(body: [String: Any], key: String) async throws -> Data {
        guard !key.isEmpty else { throw OpenRouterClientError.invalidKey }
        var req = URLRequest(url: base.appendingPathComponent("chat/completions"))
        req.httpMethod = "POST"
        req.setValue("Bearer \(key)", forHTTPHeaderField: "Authorization")
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.setValue("ZK Agent", forHTTPHeaderField: "X-Title")
        req.httpBody = try JSONSerialization.data(withJSONObject: body)
        req.timeoutInterval = 120

        let (data, response) = try await URLSession.shared.data(for: req)
        guard let http = response as? HTTPURLResponse else { throw OpenRouterClientError.badResponse }
        if !(200..<300).contains(http.statusCode) {
            if let root = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
               let error = root["error"] as? [String: Any],
               let message = error["message"] as? String {
                throw OpenRouterClientError.api(message)
            }
            throw OpenRouterClientError.api("OpenRouter request failed (HTTP \(http.statusCode)).")
        }
        return data
    }

    private func extractMessageText(_ data: Data) throws -> String {
        guard let root = try JSONSerialization.jsonObject(with: data) as? [String: Any],
              let choices = root["choices"] as? [[String: Any]],
              let first = choices.first,
              let message = first["message"] as? [String: Any] else {
            throw OpenRouterClientError.badResponse
        }

        if let content = message["content"] as? String, !content.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            return stripCodeFence(content)
        }
        if let content = message["content"] as? [[String: Any]] {
            let joined = content.compactMap { part -> String? in
                if let text = part["text"] as? String { return text }
                return nil
            }.joined(separator: "\n")
            if !joined.isEmpty { return stripCodeFence(joined) }
        }
        throw OpenRouterClientError.noText
    }

    private func stripCodeFence(_ text: String) -> String {
        var value = text.trimmingCharacters(in: .whitespacesAndNewlines)
        if value.hasPrefix("```json") { value.removeFirst(7) }
        else if value.hasPrefix("```") { value.removeFirst(3) }
        if value.hasSuffix("```") { value.removeLast(3) }
        return value.trimmingCharacters(in: .whitespacesAndNewlines)
    }
}
