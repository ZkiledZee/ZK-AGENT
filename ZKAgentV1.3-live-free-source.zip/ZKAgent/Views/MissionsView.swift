import SwiftUI

struct MissionsView: View {
    @EnvironmentObject var app: AppState
    @State private var title=""
    @State private var objective=""
    @State private var editing=false
    var body: some View {
        NavigationStack {
            List {
                Section("Active mission") {
                    ForEach(app.missions){m in VStack(alignment:.leading,spacing:10){HStack{Text(m.title).font(.headline);Spacer();Text(m.status).font(.caption).foregroundStyle(.secondary)};Text(m.objective).font(.subheadline).foregroundStyle(.secondary);ProgressView(value:m.progress);Button("Edit mission"){title=m.title;objective=m.objective;editing=true}}.padding(.vertical,5)}
                }
                Section("Live researched opportunities") {
                    if app.opportunities.isEmpty { Text("None yet. Run the live agent; this page no longer creates demo cards.").foregroundStyle(.secondary) }
                    ForEach(app.opportunities){o in NavigationLink{OpportunityDetailView(opportunity:o)} label:{VStack(alignment:.leading,spacing:6){HStack{Text(o.title).font(.subheadline.bold());Spacer();Text("\(o.score)/100").font(.caption.bold())};Text(o.category).font(.caption).foregroundStyle(.secondary);Text(o.evidence).font(.caption2).foregroundStyle(.secondary).lineLimit(3)}} }
                }
            }.navigationTitle("Missions").sheet(isPresented:$editing){NavigationStack{Form{Section("Mission"){TextField("Title",text:$title);TextEditor(text:$objective).frame(minHeight:150)};Section{Button("Save mission"){app.updateMission(title:title.isEmpty ? "Mission":title,objective:objective);editing=false}.disabled(objective.trimmingCharacters(in:.whitespacesAndNewlines).isEmpty)}}.navigationTitle("Edit Mission").toolbar{ToolbarItem(placement:.cancellationAction){Button("Cancel"){editing=false}}}}}
        }
    }
}

struct OpportunityDetailView:View{let opportunity:Opportunity;var body:some View{List{Section{LabeledContent("Score",value:"\(opportunity.score)/100");LabeledContent("Startup cost",value:String(format:"£%.0f",opportunity.startupCost));LabeledContent("Revenue estimate",value:"£\(Int(opportunity.estimatedRevenueLow))–£\(Int(opportunity.estimatedRevenueHigh))")};Section("Evidence"){Text(opportunity.evidence);Text(opportunity.whyNow).foregroundStyle(.secondary)};Section("Next actions"){ForEach(Array(opportunity.nextActions.enumerated()),id:\.offset){i,a in Text("\(i+1). \(a)")}};Section("Sources"){ForEach(opportunity.sources){s in if let url=URL(string:s.url){Link(destination:url){Label(s.title,systemImage:"arrow.up.right.square")}}}}}.navigationTitle(opportunity.title).navigationBarTitleDisplayMode(.inline)}}
