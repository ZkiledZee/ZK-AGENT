import SwiftUI

struct AgentView: View {
    @EnvironmentObject var app: AppState
    @State private var showError = false

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 18) {
                    header
                    AgentCore(state: app.state, running: app.isRunning).frame(height: 330)
                    CurrentTaskCard()
                    if !app.hasKey { SetupCard() }
                    Button(action: app.toggleAgent) {
                        Label(app.isRunning ? "Stop Agent" : "Run Live Agent", systemImage: app.isRunning ? "stop.fill" : "play.fill")
                            .frame(maxWidth:.infinity).padding(.vertical,15).font(.headline)
                    }.buttonStyle(.borderedProminent).tint(.white).foregroundStyle(.black)
                    HStack(spacing:10){ StatCard(title:"Revenue",value:app.revenue,prefix:"£"); StatCard(title:"Found",text:"\(app.opportunities.count)"); StatCard(title:"Work",text:"\(app.artifacts.count)") }
                    if !app.approvals.isEmpty { VStack(alignment:.leading,spacing:12){ Text("Needs approval").font(.headline); ForEach(app.approvals){ApprovalCard(request:$0)} } }
                    if let best=app.opportunities.first { TopOpportunityCard(opportunity:best) }
                    activityFeed
                }.padding(.horizontal,16).padding(.bottom,28)
            }.navigationTitle("")
            .onChange(of: app.lastError){ new in if new != nil { showError=true } }
            .alert("ZK Agent", isPresented:$showError){ Button("OK",role:.cancel){} } message:{ Text(app.lastError ?? "Unknown error") }
        }
    }

    private var header: some View { HStack(alignment:.top){ VStack(alignment:.leading,spacing:5){ Text("ZK AGENT").font(.title2.bold()); HStack(spacing:7){ Circle().fill(app.isRunning ? .green : .secondary).frame(width:7,height:7); Text(app.isRunning ? "ACTIVE" : "READY").font(.caption.weight(.semibold)).foregroundStyle(.secondary) } }; Spacer(); VStack(alignment:.trailing,spacing:7){ Text(app.mode.rawValue).font(.caption.bold()).padding(.horizontal,10).padding(.vertical,6).background(.white.opacity(0.08),in:Capsule()); Text(app.connectionState.rawValue).font(.caption2.bold()).foregroundStyle(app.connectionState == .live ? .green : .secondary) } }.padding(.top,8) }

    private var activityFeed: some View { VStack(alignment:.leading,spacing:12){ HStack{Text("Activity").font(.headline);Spacer();Text(app.connectionState == .live ? "REAL AI" : "NO DEMO DATA").font(.caption2.bold()).foregroundStyle(.secondary)}; ForEach(app.activity.prefix(10)){e in HStack(alignment:.top,spacing:12){ Circle().fill(eventColor(e.state)).frame(width:8,height:8).padding(.top,6); VStack(alignment:.leading,spacing:3){Text(e.title).font(.subheadline.weight(.semibold));Text(e.detail).font(.caption).foregroundStyle(.secondary);Text(e.timestamp,style:.time).font(.caption2).foregroundStyle(.tertiary)};Spacer()} } } }
    private func eventColor(_ s:AgentState)->Color{ switch s{case .success:return .green;case .warning:return .orange;case .waitingApproval:return .yellow;case .scanning:return .cyan;case .researching:return .blue;case .comparing:return .purple;case .building:return .mint;case .idle:return .secondary} }
}

struct SetupCard: View { var body: some View { VStack(alignment:.leading,spacing:7){ Label("AI setup required",systemImage:"key.fill").font(.headline); Text("Add a free OpenRouter API key in Settings. Until then the app will not invent opportunities or pretend to be working.").font(.caption).foregroundStyle(.secondary) }.frame(maxWidth:.infinity,alignment:.leading).padding(15).background(.orange.opacity(0.10),in:RoundedRectangle(cornerRadius:16)) } }

struct TopOpportunityCard: View { let opportunity:Opportunity; var body: some View { VStack(alignment:.leading,spacing:8){ HStack{Text("Top live finding").font(.caption.bold()).foregroundStyle(.secondary);Spacer();Text("\(opportunity.score)/100").font(.headline)};Text(opportunity.title).font(.headline);Text(opportunity.evidence).font(.caption).foregroundStyle(.secondary);Text("Est. £\(Int(opportunity.estimatedRevenueLow))–£\(Int(opportunity.estimatedRevenueHigh))").font(.caption.bold()) }.frame(maxWidth:.infinity,alignment:.leading).padding(15).background(.white.opacity(0.055),in:RoundedRectangle(cornerRadius:18)) } }

struct CurrentTaskCard: View { @EnvironmentObject var app:AppState; var body:some View{ VStack(alignment:.leading,spacing:10){HStack{Text(app.currentTask).font(.headline);Spacer();Text("\(Int(app.cycleProgress*100))%").font(.caption.bold()).foregroundStyle(.secondary)};Text(app.currentDetail).font(.caption).foregroundStyle(.secondary);ProgressView(value:app.cycleProgress).tint(.white);HStack{Label(app.selectedModel.label,systemImage:"brain.head.profile");Spacer();Label(app.connectionState.rawValue,systemImage:"network")}.font(.caption2).foregroundStyle(.secondary)}.padding(15).background(.white.opacity(0.055),in:RoundedRectangle(cornerRadius:18)) } }

struct AgentCore: View {
    let state:AgentState; let running:Bool
    var body:some View{ TimelineView(.animation(minimumInterval:1/30,paused:!running)){ctx in GeometryReader{g in let t=ctx.date.timeIntervalSinceReferenceDate; let s=min(g.size.width,g.size.height); ZStack{ ForEach(0..<5,id:\.self){i in Circle().stroke(.white.opacity(0.05+Double(4-i)*0.02),lineWidth:i==0 ? 2:1).frame(width:s*(0.40+CGFloat(i)*0.12),height:s*(0.40+CGFloat(i)*0.12)).scaleEffect(running ? 1+CGFloat(sin(t*2+Double(i)))*0.018:1) }; Canvas{c,sz in let p=CGPoint(x:sz.width/2,y:sz.height/2); for i in 0..<(running ? 22:10){let a=Double(i)/22*Double.pi*2+t*(state == .scanning ? 1.8:0.8)*(i%2==0 ? 1:-1);let r=s*CGFloat(0.25+Double(i%5)*0.045);let x=p.x+CGFloat(cos(a))*r;let y=p.y+CGFloat(sin(a))*r;let d=CGFloat(i%6==0 ? 6:3);c.fill(Path(ellipseIn:CGRect(x:x-d/2,y:y-d/2,width:d,height:d)),with:.color(accent.opacity(0.25+Double(i%4)*0.12)))} }; effect(size:s,time:t); ZStack{Circle().fill(RadialGradient(colors:[accent.opacity(0.34),.white.opacity(0.06),.clear],center:.center,startRadius:2,endRadius:s*0.27)).frame(width:s*0.58,height:s*0.58).scaleEffect(running ? 1+CGFloat(sin(t*3))*0.05:1);Circle().fill(.black).frame(width:s*0.31,height:s*0.31).overlay(Circle().stroke(accent,lineWidth:3)).shadow(color:accent.opacity(0.4),radius:22);VStack(spacing:7){Image(systemName:icon).font(.system(size:38,weight:.semibold));Text(label).font(.caption.bold()).tracking(1.4)}.foregroundStyle(.white)} } } } }
    @ViewBuilder private func effect(size:CGFloat,time:TimeInterval)->some View{ switch state{case .scanning: Capsule().fill(LinearGradient(colors:[.clear,.cyan.opacity(0.8),.clear],startPoint:.leading,endPoint:.trailing)).frame(width:size*0.82,height:4).rotationEffect(.degrees(time*100));case .researching: ForEach(0..<4,id:\.self){i in Circle().trim(from:0.02,to:0.25+CGFloat(i)*0.12).stroke(i==0 ? .blue:.white.opacity(0.25),style:StrokeStyle(lineWidth:i==0 ? 4:2,lineCap:.round)).frame(width:size*(0.38+CGFloat(i)*0.1),height:size*(0.38+CGFloat(i)*0.1)).rotationEffect(.degrees(time*Double(50+i*22)*(i%2==0 ? 1:-1)))};case .comparing:HStack(spacing:13){ForEach(0..<5,id:\.self){i in RoundedRectangle(cornerRadius:5).fill(.purple.opacity(0.3+0.6*abs(sin(time*1.6+Double(i))))).frame(width:13,height:CGFloat(26+i*10))}}.offset(y:74);case .building:ForEach(0..<12,id:\.self){i in let a=Double(i)/12*Double.pi*2;let wave=(sin(time*2.6+Double(i))+1)/2;RoundedRectangle(cornerRadius:4).fill(i%2==0 ? .mint:.white.opacity(0.8)).frame(width:14,height:14).offset(x:CGFloat(cos(a))*size*CGFloat(0.31-wave*0.17),y:CGFloat(sin(a))*size*CGFloat(0.31-wave*0.17)).rotationEffect(.degrees(time*100+Double(i*18)))};case .waitingApproval:Circle().stroke(.yellow,style:StrokeStyle(lineWidth:4,dash:[8,9])).frame(width:size*0.5,height:size*0.5).rotationEffect(.degrees(time*45));case .success:ForEach(0..<12,id:\.self){i in let a=Double(i)/12*Double.pi*2;Capsule().fill(.green).frame(width:4,height:24).offset(x:CGFloat(cos(a))*size*0.29,y:CGFloat(sin(a))*size*0.29).rotationEffect(.radians(a + Double.pi / 2))};case .warning:Circle().stroke(.orange,lineWidth:4).frame(width:size*0.48,height:size*0.48).scaleEffect(1+CGFloat(sin(time*5))*0.05);case .idle:EmptyView()} }
    private var label:String{switch state{case .idle:return "READY";case .scanning:return "SEARCH";case .researching:return "RESEARCH";case .comparing:return "SCORE";case .building:return "BUILD";case .waitingApproval:return "APPROVE";case .success:return "DONE";case .warning:return "CHECK"}}
    private var icon:String{switch state{case .idle:return "brain.head.profile";case .scanning:return "dot.radiowaves.left.and.right";case .researching:return "globe.americas.fill";case .comparing:return "chart.bar.xaxis";case .building:return "hammer.fill";case .waitingApproval:return "hand.raised.fill";case .success:return "checkmark.seal.fill";case .warning:return "exclamationmark.triangle.fill"}}
    private var accent:Color{switch state{case .idle:return .white;case .scanning:return .cyan;case .researching:return .blue;case .comparing:return .purple;case .building:return .mint;case .waitingApproval:return .yellow;case .success:return .green;case .warning:return .orange}}
}

struct StatCard:View{let title:String;var value:Double?=nil;var text:String?=nil;var prefix:String="";var body:some View{VStack(alignment:.leading,spacing:7){Text(title).font(.caption2).foregroundStyle(.secondary);Text(text ?? String(format:"%@%.2f",prefix,value ?? 0)).font(.headline.bold()).lineLimit(1).minimumScaleFactor(0.6)}.frame(maxWidth:.infinity,alignment:.leading).padding(12).background(.white.opacity(0.055),in:RoundedRectangle(cornerRadius:16))}}
struct ApprovalCard:View{@EnvironmentObject var app:AppState;let request:ApprovalRequest;var body:some View{VStack(alignment:.leading,spacing:9){Text(request.title).font(.subheadline.bold());Text(request.reason).font(.caption).foregroundStyle(.secondary);HStack{Text("Cost £\(request.estimatedCost,specifier:"%.2f")");Spacer();Text("Risk \(request.risk)")}.font(.caption2).foregroundStyle(.secondary);HStack{Button("Reject"){app.reject(request)}.buttonStyle(.bordered);Button("Approve & prepare"){app.approve(request)}.buttonStyle(.borderedProminent).tint(.white).foregroundStyle(.black)}}.padding().background(.white.opacity(0.06),in:RoundedRectangle(cornerRadius:18))}}
