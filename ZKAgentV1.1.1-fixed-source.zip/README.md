# ZK Agent V1.1

SwiftUI iPhone control app for the ZK autonomous-agent project.

## V1.1 changes
- Rebuilt animated agent core with state-specific motion for scanning, research, compare, build, approval, success and warning.
- Larger, more visible centre animation and orbiting particles.
- Current-task panel with cycle progress and processed count.
- Explicit LOCAL / LIVE backend status.
- Backend health-check support using `GET /health`.
- Live activity feed now visually distinguishes states.
- Local placeholder opportunities are explicitly marked as simulations.

## Important
The bundled local cycle is a simulation and does not claim to search the web. Configure a backend URL and pass its `/health` check before the app displays LIVE. The next backend step is to implement real opportunity-search endpoints and return verified opportunities to the app.

Bundle ID: `com.zk.agent`
Display name: `ZK Agent`
