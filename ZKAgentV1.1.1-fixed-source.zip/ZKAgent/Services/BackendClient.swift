import Foundation

struct BackendClient {
    enum BackendError: Error { case invalidURL, invalidResponse }

    func healthCheck(baseURL: String, token: String) async throws -> Bool {
        guard let base = URL(string: baseURL.trimmingCharacters(in: .whitespacesAndNewlines)),
              let url = URL(string: "health", relativeTo: base.appendingPathComponent("/")) else {
            throw BackendError.invalidURL
        }

        var request = URLRequest(url: url)
        request.timeoutInterval = 8
        request.httpMethod = "GET"
        if !token.isEmpty { request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization") }

        let (_, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse else { throw BackendError.invalidResponse }
        return (200...299).contains(http.statusCode)
    }
}
