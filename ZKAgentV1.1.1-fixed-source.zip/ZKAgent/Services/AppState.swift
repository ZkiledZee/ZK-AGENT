import Foundation
import SwiftUI

@MainActor
final class AppState: ObservableObject {
    @Published var mode: AgentMode = .assist
    @Published var state: AgentState = .idle
    @Published var isRunning = false
    @Published var revenue: Double = 0
    @Published var spend: Double = 0
    @Published var opportunities: [Opportunity] = []
    @Published var missions: [Mission] = []
    @Published var approvals: [ApprovalRequest] = []
    @Published var activity: [ActivityEvent] = []
    @Published var ledger: [LedgerEntry] = []
    @Published var backendURL: String = ""
    @Published var apiToken: String = ""

    @Published var backendState: BackendConnectionState = .local
    @Published var cycleProgress: Double = 0
    @Published var currentTask: String = "Waiting for a mission"
    @Published var currentDetail: String = "The agent is ready."
    @Published var itemsProcessed: Int = 0

    private var loopTask: Task<Void, Never>?
    private let storage = LocalStore()
    private let backend = BackendClient()

    init() {
        load()
        backendState = backendURL.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? .local : .failed
        if missions.isEmpty {
            missions = [Mission(id: UUID(), title: "Zero-Cost Income", objective: "Find legitimate £0-startup opportunities with the fastest path to revenue.", progress: 0, status: "Ready", createdAt: Date())]
        }
        if activity.isEmpty {
            activity = [ActivityEvent(title: "Agent ready", detail: "Local engine ready. Connect the live backend to enable verified web actions.", state: .idle)]
        }
    }

    var isLiveBackend: Bool { backendState == .live }

    func toggleAgent() { isRunning ? stop() : start() }

    func start() {
        guard !isRunning else { return }
        isRunning = true
        cycleProgress = 0
        itemsProcessed = 0
        currentTask = "Starting mission"
        currentDetail = isLiveBackend ? "Connecting to live tools." : "Running the local V1.1 simulation engine."
        log("Mission started", currentDetail, .scanning)
        loopTask = Task { [weak self] in
            guard let self else { return }
            await self.runCycle()
        }
    }

    func stop() {
        isRunning = false
        state = .idle
        cycleProgress = 0
        currentTask = "Agent paused"
        currentDetail = "Automation stopped safely."
        loopTask?.cancel()
        loopTask = nil
        log("Agent paused", "Automation stopped safely.", .idle)
        save()
    }

    private func runCycle() async {
        // Until the backend exposes the opportunity API, V1.1 keeps the local cycle explicit.
        let phases: [(AgentState, String, String, Double, Int)] = [
            (.scanning, "Scanning sources", "Checking configured opportunity sources.", 0.18, 21),
            (.researching, "Researching evidence", "Reviewing demand, freshness and startup requirements.", 0.43, 48),
            (.comparing, "Ranking candidates", "Scoring cost, speed, demand and automation potential.", 0.68, 73),
            (.building, "Building action plan", "Assembling the next safe action for the strongest candidate.", 0.90, 86)
        ]

        for phase in phases {
            guard isRunning, !Task.isCancelled else { return }
            state = phase.0
            currentTask = phase.1
            currentDetail = phase.2
            cycleProgress = phase.3
            itemsProcessed = phase.4
            log(phase.1, phase.2, phase.0)
            try? await Task.sleep(nanoseconds: 1_250_000_000)
        }

        guard isRunning else { return }
        let sample = Opportunity(
            id: UUID(),
            title: "Local service lead qualification",
            category: "Lead generation",
            score: 82,
            startupCost: 0,
            estimatedRevenue: 40,
            evidence: "LOCAL SIMULATION — connect the backend to replace this card with verified live evidence.",
            status: "Needs live verification"
        )
        opportunities.insert(sample, at: 0)
        cycleProgress = 1
        itemsProcessed = 100

        if mode == .watch {
            state = .success
            currentTask = "Candidate recorded"
            currentDetail = "WATCH mode stopped before taking action."
            log("Opportunity recorded", sample.title, .success)
        } else {
            state = .waitingApproval
            currentTask = "Waiting for approval"
            currentDetail = "A candidate reached the action threshold."
            approvals.insert(ApprovalRequest(id: UUID(), title: "Verify & prepare outreach", reason: "The local candidate reached the action threshold. A live backend is required for real verification.", estimatedCost: 0, risk: "Low", createdAt: Date()), at: 0)
            log("Approval required", "Candidate reached action threshold.", .waitingApproval)
        }
        save()
        isRunning = false
    }

    func approve(_ request: ApprovalRequest) {
        approvals.removeAll { $0.id == request.id }
        currentTask = "Action approved"
        currentDetail = request.title
        log("Approved", request.title, .building)
        if let idx = missions.indices.first {
            missions[idx].progress = min(1, missions[idx].progress + 0.2)
            missions[idx].status = "In progress"
        }
        save()
    }

    func reject(_ request: ApprovalRequest) {
        approvals.removeAll { $0.id == request.id }
        currentTask = "Action rejected"
        currentDetail = request.title
        log("Rejected", request.title, .warning)
        save()
    }

    func addRevenue(_ amount: Double, note: String) {
        guard amount > 0 else { return }
        revenue += amount
        ledger.insert(LedgerEntry(id: UUID(), timestamp: Date(), type: "Revenue", amount: amount, note: note), at: 0)
        log("Revenue recorded", String(format: "£%.2f — %@", amount, note), .success)
        save()
    }

    func addExpense(_ amount: Double, note: String) {
        guard amount > 0 else { return }
        spend += amount
        ledger.insert(LedgerEntry(id: UUID(), timestamp: Date(), type: "Expense", amount: -amount, note: note), at: 0)
        save()
    }

    func saveSettings() {
        backendState = backendURL.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? .local : .failed
        save()
    }

    func testBackend() async {
        let trimmed = backendURL.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else {
            backendState = .local
            log("Local mode", "No backend URL configured.", .idle)
            return
        }
        backendState = .testing
        currentTask = "Testing backend"
        currentDetail = trimmed
        do {
            let ok = try await backend.healthCheck(baseURL: trimmed, token: apiToken)
            backendState = ok ? .live : .failed
            log(ok ? "Backend live" : "Backend rejected", ok ? "Live agent service responded successfully." : "Health endpoint returned an error.", ok ? .success : .warning)
        } catch {
            backendState = .failed
            log("Backend offline", "Could not reach the configured health endpoint.", .warning)
        }
        save()
    }

    private func log(_ title: String, _ detail: String, _ state: AgentState) {
        self.state = state
        activity.insert(ActivityEvent(title: title, detail: detail, state: state), at: 0)
        if activity.count > 100 { activity = Array(activity.prefix(100)) }
    }

    private func load() {
        guard let snapshot = storage.load() else { return }
        mode = snapshot.mode
        revenue = snapshot.revenue
        spend = snapshot.spend
        opportunities = snapshot.opportunities
        missions = snapshot.missions
        approvals = snapshot.approvals
        activity = snapshot.activity
        ledger = snapshot.ledger
        backendURL = snapshot.backendURL
        apiToken = snapshot.apiToken
    }

    private func save() {
        storage.save(Snapshot(mode: mode, revenue: revenue, spend: spend, opportunities: opportunities, missions: missions, approvals: approvals, activity: activity, ledger: ledger, backendURL: backendURL, apiToken: apiToken))
    }
}

struct Snapshot: Codable {
    let mode: AgentMode
    let revenue: Double
    let spend: Double
    let opportunities: [Opportunity]
    let missions: [Mission]
    let approvals: [ApprovalRequest]
    let activity: [ActivityEvent]
    let ledger: [LedgerEntry]
    let backendURL: String
    let apiToken: String
}

final class LocalStore {
    private var url: URL? {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first?.appendingPathComponent("zkagent.json")
    }
    func save(_ snapshot: Snapshot) {
        guard let url, let data = try? JSONEncoder().encode(snapshot) else { return }
        try? data.write(to: url, options: .atomic)
    }
    func load() -> Snapshot? {
        guard let url, let data = try? Data(contentsOf: url) else { return nil }
        return try? JSONDecoder().decode(Snapshot.self, from: data)
    }
}
