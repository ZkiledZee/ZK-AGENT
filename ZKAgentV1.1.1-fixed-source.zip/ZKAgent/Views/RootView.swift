import SwiftUI

struct RootView: View {
    var body: some View {
        TabView {
            AgentView().tabItem { Label("Agent", systemImage: "sparkles") }
            MissionsView().tabItem { Label("Missions", systemImage: "scope") }
            MoneyView().tabItem { Label("Money", systemImage: "sterlingsign.circle") }
            SettingsView().tabItem { Label("Settings", systemImage: "gearshape") }
        }
        .tint(.white)
    }
}
