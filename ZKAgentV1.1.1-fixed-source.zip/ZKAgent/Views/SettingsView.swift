import SwiftUI

struct SettingsView: View {
    @EnvironmentObject var app: AppState

    var body: some View {
        NavigationStack {
            Form {
                Section("Agent status") {
                    HStack {
                        Label("Engine", systemImage: app.backendState == .live ? "network" : "iphone")
                        Spacer()
                        Text(app.backendState.rawValue)
                            .font(.caption.bold())
                            .foregroundStyle(app.backendState == .live ? .green : .secondary)
                    }
                    Text(app.backendState == .live ? "Verified live backend connected." : "The app is currently using the local simulation engine. No live web activity is being claimed.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                Section("Autonomy") {
                    Picker("Mode", selection: $app.mode) {
                        ForEach(AgentMode.allCases, id: \.self) { Text($0.rawValue).tag($0) }
                    }
                    Text("WATCH only records. ASSIST asks before actions. AUTOPILOT is for explicitly approved low-risk tools only.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                Section("Backend connection") {
                    TextField("https://your-backend.example/", text: $app.backendURL)
                        .textInputAutocapitalization(.never)
                        .keyboardType(.URL)
                    SecureField("API token", text: $app.apiToken)
                    Button("Save connection") { app.saveSettings() }
                    Button {
                        Task { await app.testBackend() }
                    } label: {
                        HStack {
                            Text(app.backendState == .testing ? "Testing…" : "Test live backend")
                            if app.backendState == .testing {
                                Spacer()
                                ProgressView()
                            }
                        }
                    }
                    .disabled(app.backendState == .testing)
                    Text("The backend should expose GET /health. V1.1 uses this to prove a real service is connected before showing LIVE.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                Section("Next live tools") {
                    Label("Web opportunity research", systemImage: "globe")
                    Label("Local business discovery", systemImage: "building.2")
                    Label("Evidence + freshness verification", systemImage: "checkmark.shield")
                    Label("Approval-based outreach actions", systemImage: "paperplane")
                }

                Section("Safety") {
                    Label("No wallet private keys stored", systemImage: "lock.shield")
                    Label("Spending requires explicit approval", systemImage: "hand.raised")
                    Label("LIVE only appears after backend verification", systemImage: "checkmark.seal")
                }
            }
            .navigationTitle("Settings")
        }
    }
}
