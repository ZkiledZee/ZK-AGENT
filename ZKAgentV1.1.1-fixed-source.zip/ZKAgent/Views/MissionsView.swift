import SwiftUI

struct MissionsView: View {
    @EnvironmentObject var app: AppState
    var body: some View {
        NavigationStack {
            List {
                Section("Active mission") {
                    ForEach(app.missions) { mission in
                        VStack(alignment: .leading, spacing: 10) {
                            HStack { Text(mission.title).font(.headline); Spacer(); Text(mission.status).font(.caption).foregroundStyle(.secondary) }
                            Text(mission.objective).font(.subheadline).foregroundStyle(.secondary)
                            ProgressView(value: mission.progress)
                        }.padding(.vertical, 6)
                    }
                }
                Section("Opportunities") {
                    if app.opportunities.isEmpty { Text("No opportunities recorded yet.").foregroundStyle(.secondary) }
                    ForEach(app.opportunities) { item in
                        VStack(alignment: .leading, spacing: 6) {
                            HStack { Text(item.title).font(.subheadline.bold()); Spacer(); Text("\(item.score)/100").font(.caption.bold()) }
                            Text(item.category).font(.caption).foregroundStyle(.secondary)
                            Text(item.evidence).font(.caption2).foregroundStyle(.secondary)
                        }.padding(.vertical, 5)
                    }
                }
            }.navigationTitle("Missions")
        }
    }
}
