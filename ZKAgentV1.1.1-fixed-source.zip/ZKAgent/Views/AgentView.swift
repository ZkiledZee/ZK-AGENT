import SwiftUI

struct AgentView: View {
    @EnvironmentObject var app: AppState

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 20) {
                    header

                    AgentCore(state: app.state, running: app.isRunning)
                        .frame(height: 320)

                    CurrentTaskCard()

                    Button(action: app.toggleAgent) {
                        Label(app.isRunning ? "Pause Agent" : "Run Agent", systemImage: app.isRunning ? "pause.fill" : "play.fill")
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 16)
                            .font(.headline)
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(.white)
                    .foregroundStyle(.black)

                    HStack(spacing: 10) {
                        StatCard(title: "Revenue", value: app.revenue, prefix: "£")
                        StatCard(title: "Found", text: "\(app.opportunities.count)")
                        StatCard(title: "Approvals", text: "\(app.approvals.count)")
                    }

                    if !app.approvals.isEmpty {
                        VStack(alignment: .leading, spacing: 12) {
                            Text("Needs approval").font(.headline)
                            ForEach(app.approvals) { request in ApprovalCard(request: request) }
                        }
                    }

                    activityFeed
                }
                .padding(.horizontal, 16)
                .padding(.bottom, 24)
            }
            .navigationTitle("")
        }
    }

    private var header: some View {
        HStack(alignment: .top) {
            VStack(alignment: .leading, spacing: 5) {
                Text("ZK AGENT")
                    .font(.title2.bold())
                HStack(spacing: 7) {
                    Circle()
                        .fill(app.isRunning ? Color.green : Color.secondary)
                        .frame(width: 7, height: 7)
                    Text(app.isRunning ? "ACTIVE" : "READY")
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(.secondary)
                }
            }
            Spacer()
            VStack(alignment: .trailing, spacing: 8) {
                Text(app.mode.rawValue)
                    .font(.caption.bold())
                    .padding(.horizontal, 10)
                    .padding(.vertical, 6)
                    .background(.white.opacity(0.08), in: Capsule())
                Text(app.backendState.rawValue)
                    .font(.caption2.bold())
                    .foregroundStyle(app.backendState == .live ? .green : .secondary)
            }
        }
        .padding(.top, 8)
    }

    private var activityFeed: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text("Live activity").font(.headline)
                Spacer()
                Text(app.backendState == .live ? "VERIFIED LIVE" : "LOCAL ENGINE")
                    .font(.caption2.bold())
                    .foregroundStyle(.secondary)
            }

            ForEach(app.activity.prefix(12)) { event in
                HStack(alignment: .top, spacing: 12) {
                    ZStack {
                        Circle().fill(eventColor(event.state).opacity(0.18)).frame(width: 22, height: 22)
                        Circle().fill(eventColor(event.state)).frame(width: 7, height: 7)
                    }
                    .padding(.top, 1)

                    VStack(alignment: .leading, spacing: 3) {
                        Text(event.title).font(.subheadline.weight(.semibold))
                        Text(event.detail).font(.caption).foregroundStyle(.secondary)
                        Text(event.timestamp, style: .time).font(.caption2).foregroundStyle(.tertiary)
                    }
                    Spacer()
                }
            }
        }
    }

    private func eventColor(_ state: AgentState) -> Color {
        switch state {
        case .success: return .green
        case .warning: return .orange
        case .waitingApproval: return .yellow
        case .scanning: return .cyan
        case .researching: return .blue
        case .comparing: return .purple
        case .building: return .mint
        case .idle: return .secondary
        }
    }
}

struct CurrentTaskCard: View {
    @EnvironmentObject var app: AppState

    var body: some View {
        VStack(alignment: .leading, spacing: 11) {
            HStack {
                Text(app.currentTask)
                    .font(.headline)
                Spacer()
                Text("\(Int(app.cycleProgress * 100))%")
                    .font(.caption.bold())
                    .foregroundStyle(.secondary)
            }

            Text(app.currentDetail)
                .font(.caption)
                .foregroundStyle(.secondary)

            GeometryReader { geo in
                ZStack(alignment: .leading) {
                    Capsule().fill(.white.opacity(0.08))
                    Capsule().fill(.white.opacity(0.9))
                        .frame(width: max(4, geo.size.width * app.cycleProgress))
                }
            }
            .frame(height: 5)

            HStack {
                Label("\(app.itemsProcessed) processed", systemImage: "waveform.path.ecg")
                Spacer()
                Label(app.backendState.rawValue, systemImage: app.backendState == .live ? "network" : "iphone")
            }
            .font(.caption2.weight(.medium))
            .foregroundStyle(.secondary)
        }
        .padding(15)
        .background(.white.opacity(0.055), in: RoundedRectangle(cornerRadius: 18))
    }
}

struct AgentCore: View {
    let state: AgentState
    let running: Bool

    var body: some View {
        TimelineView(.animation(minimumInterval: 1.0 / 30.0, paused: !running)) { context in
            GeometryReader { geo in
                let t = context.date.timeIntervalSinceReferenceDate
                let size = min(geo.size.width, geo.size.height)
                let center = CGPoint(x: geo.size.width / 2, y: geo.size.height / 2)

                ZStack {
                    backgroundRings(size: size, time: t)
                    orbitLayer(size: size, center: center, time: t)
                    stateEffect(size: size, time: t)
                    core(size: size, time: t)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
        }
    }

    @ViewBuilder
    private func backgroundRings(size: CGFloat, time: TimeInterval) -> some View {
        let breathe = running ? 1.0 + CGFloat(sin(time * 2.0)) * 0.035 : 1.0
        ForEach(0..<4, id: \.self) { i in
            Circle()
                .stroke(.white.opacity(0.075 + Double(3 - i) * 0.02), lineWidth: i == 0 ? 2 : 1)
                .frame(width: size * (0.42 + CGFloat(i) * 0.14), height: size * (0.42 + CGFloat(i) * 0.14))
                .scaleEffect(breathe + CGFloat(i) * 0.008)
        }
    }

    @ViewBuilder
    private func orbitLayer(size: CGFloat, center: CGPoint, time: TimeInterval) -> some View {
        Canvas { context, canvasSize in
            let c = CGPoint(x: canvasSize.width / 2, y: canvasSize.height / 2)
            let count = running ? 16 : 8
            for i in 0..<count {
                let base = Double(i) / Double(count) * Double.pi * 2
                let speed = state == .scanning ? 1.55 : (state == .building ? 1.15 : 0.75)
                let angle = base + time * speed * (i % 2 == 0 ? 1 : -1)
                let ring = CGFloat(0.26 + Double(i % 4) * 0.045)
                let radius = size * ring
                let x = c.x + CGFloat(cos(angle)) * radius
                let y = c.y + CGFloat(sin(angle)) * radius
                let particle = CGFloat(i % 5 == 0 ? 6 : 3.2)
                let alpha = running ? 0.30 + Double(i % 4) * 0.11 : 0.18
                context.fill(Path(ellipseIn: CGRect(x: x - particle/2, y: y - particle/2, width: particle, height: particle)), with: .color(.white.opacity(alpha)))
            }
        }
    }

    @ViewBuilder
    private func stateEffect(size: CGFloat, time: TimeInterval) -> some View {
        switch state {
        case .scanning:
            Capsule()
                .fill(LinearGradient(colors: [.clear, .cyan.opacity(0.5), .clear], startPoint: .leading, endPoint: .trailing))
                .frame(width: size * 0.74, height: 3)
                .rotationEffect(.degrees(time * 95))
                .blur(radius: 0.4)

        case .researching:
            ForEach(0..<3, id: \.self) { i in
                Circle()
                    .trim(from: 0.05, to: 0.34 + CGFloat(i) * 0.12)
                    .stroke(i == 0 ? Color.blue.opacity(0.8) : Color.white.opacity(0.28), style: StrokeStyle(lineWidth: i == 0 ? 3 : 2, lineCap: .round))
                    .frame(width: size * (0.36 + CGFloat(i) * 0.10), height: size * (0.36 + CGFloat(i) * 0.10))
                    .rotationEffect(.degrees(time * Double(60 + i * 22) * (i % 2 == 0 ? 1 : -1)))
            }

        case .comparing:
            HStack(spacing: 16) {
                ForEach(0..<3, id: \.self) { i in
                    RoundedRectangle(cornerRadius: 6)
                        .fill(.white.opacity(i == Int(abs(sin(time * 1.8)) * 3).clamped(to: 0...2) ? 0.75 : 0.15))
                        .frame(width: 18, height: CGFloat(34 + i * 12))
                }
            }
            .offset(y: 62)

        case .building:
            ForEach(0..<8, id: \.self) { i in
                let angle = Double(i) / 8.0 * Double.pi * 2
                let wave = (sin(time * 2.4 + Double(i)) + 1) / 2
                let radius = size * CGFloat(0.28 - wave * 0.13)
                RoundedRectangle(cornerRadius: 5)
                    .fill(i % 2 == 0 ? Color.mint.opacity(0.9) : Color.white.opacity(0.72))
                    .frame(width: 15, height: 15)
                    .offset(x: CGFloat(cos(angle)) * radius, y: CGFloat(sin(angle)) * radius)
                    .rotationEffect(.degrees(time * 90 + Double(i * 20)))
            }

        case .waitingApproval:
            Circle()
                .stroke(Color.yellow.opacity(0.7), style: StrokeStyle(lineWidth: 3, dash: [7, 8]))
                .frame(width: size * 0.46, height: size * 0.46)
                .rotationEffect(.degrees(time * 42))

        case .success:
            ForEach(0..<10, id: \.self) { i in
                let a = Double(i) / 10 * Double.pi * 2
                Capsule()
                    .fill(Color.green.opacity(0.7))
                    .frame(width: 4, height: 22)
                    .offset(x: CGFloat(cos(a)) * size * 0.28, y: CGFloat(sin(a)) * size * 0.28)
                    .rotationEffect(.radians(a + .pi / 2))
            }

        case .warning:
            Circle()
                .stroke(Color.orange.opacity(0.65), lineWidth: 4)
                .frame(width: size * 0.48, height: size * 0.48)
                .scaleEffect(1 + CGFloat(sin(time * 5)) * 0.05)

        case .idle:
            EmptyView()
        }
    }

    @ViewBuilder
    private func core(size: CGFloat, time: TimeInterval) -> some View {
        let pulse = running ? 1.0 + CGFloat(sin(time * 2.8)) * 0.045 : 1.0

        ZStack {
            Circle()
                .fill(RadialGradient(colors: [accent.opacity(0.25), .white.opacity(0.07), .clear], center: .center, startRadius: 1, endRadius: size * 0.24))
                .frame(width: size * 0.50, height: size * 0.50)
                .scaleEffect(pulse)
                .blur(radius: 2)

            Circle()
                .fill(.black)
                .frame(width: size * 0.31, height: size * 0.31)
                .overlay(Circle().stroke(accent.opacity(0.85), lineWidth: 2.5))
                .shadow(color: accent.opacity(0.28), radius: 18)

            VStack(spacing: 8) {
                Image(systemName: icon)
                    .font(.system(size: 34, weight: .semibold))
                                    Text(label)
                    .font(.caption.bold())
                    .tracking(1.3)
            }
            .foregroundStyle(.white)
        }
    }

    private var label: String {
        switch state {
        case .idle: return "IDLE"
        case .scanning: return "SCANNING"
        case .researching: return "RESEARCH"
        case .comparing: return "COMPARE"
        case .building: return "BUILDING"
        case .waitingApproval: return "APPROVAL"
        case .success: return "COMPLETE"
        case .warning: return "CHECK"
        }
    }

    private var icon: String {
        switch state {
        case .idle: return "circle.hexagongrid"
        case .scanning: return "dot.radiowaves.left.and.right"
        case .researching: return "doc.text.magnifyingglass"
        case .comparing: return "chart.bar.xaxis"
        case .building: return "shippingbox.and.arrow.backward"
        case .waitingApproval: return "hand.raised.fill"
        case .success: return "checkmark.seal.fill"
        case .warning: return "exclamationmark.triangle.fill"
        }
    }

    private var accent: Color {
        switch state {
        case .idle: return .white
        case .scanning: return .cyan
        case .researching: return .blue
        case .comparing: return .purple
        case .building: return .mint
        case .waitingApproval: return .yellow
        case .success: return .green
        case .warning: return .orange
        }
    }
}

private extension Comparable {
    func clamped(to limits: ClosedRange<Self>) -> Self {
        min(max(self, limits.lowerBound), limits.upperBound)
    }
}

struct StatCard: View {
    let title: String
    var value: Double? = nil
    var text: String? = nil
    var prefix: String = ""

    var body: some View {
        VStack(alignment: .leading, spacing: 7) {
            Text(title)
                .font(.caption2)
                .foregroundStyle(.secondary)
                .lineLimit(1)
            Text(text ?? String(format: "%@%.2f", prefix, value ?? 0))
                .font(.headline.bold())
                .lineLimit(1)
                .minimumScaleFactor(0.65)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(12)
        .background(.white.opacity(0.055), in: RoundedRectangle(cornerRadius: 16))
    }
}

struct ApprovalCard: View {
    @EnvironmentObject var app: AppState
    let request: ApprovalRequest

    var body: some View {
        VStack(alignment: .leading, spacing: 9) {
            Text(request.title).font(.subheadline.bold())
            Text(request.reason).font(.caption).foregroundStyle(.secondary)
            HStack {
                Text("Cost £\(request.estimatedCost, specifier: "%.2f")")
                Spacer()
                Text("Risk \(request.risk)")
            }
            .font(.caption2)
            .foregroundStyle(.secondary)

            HStack {
                Button("Reject") { app.reject(request) }.buttonStyle(.bordered)
                Button("Approve") { app.approve(request) }
                    .buttonStyle(.borderedProminent)
                    .tint(.white)
                    .foregroundStyle(.black)
            }
        }
        .padding()
        .background(.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 18))
    }
}
