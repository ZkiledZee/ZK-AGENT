# ZK Agent v1.2.0 — Live AI build

This version removes the fake local opportunity generator. **No opportunity appears unless a live AI request succeeds.**

## What works
- OpenAI Responses API from the personal sideloaded iPhone app
- GPT-5.6 Luna / Terra / Sol selection
- live web search for current opportunities
- structured opportunity scoring
- source URLs shown inside each opportunity
- editable mission and region
- approval-gated AI execution pack generation
- work/history tab
- API key stored in iOS Keychain
- real revenue ledger

## Required setup
1. Build/install the IPA.
2. In ZK Agent → Settings, paste your OpenAI API key (`sk-...`).
3. Save it, tap **Test AI connection**.
4. Edit the mission if desired.
5. Tap **Run Live Agent**.

The OpenAI API is separate from a ChatGPT subscription and can incur API usage charges.

## Safety / current limits
This build researches and prepares work. It does not automatically send messages, publish websites, spend money, move crypto, place trades, or create external accounts. Those require dedicated account integrations and explicit permissions.

## Security note
For a personal sideloaded build, BYOK is convenient. A public/distributed app should move the API key to a server-side backend.
