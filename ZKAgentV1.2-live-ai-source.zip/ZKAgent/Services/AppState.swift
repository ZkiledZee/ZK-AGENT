import Foundation
import SwiftUI

@MainActor
final class AppState: ObservableObject {
    @Published var mode: AgentMode = .assist
    @Published var selectedModel: AgentModel = .luna
    @Published var region: String = "United Kingdom"
    @Published var state: AgentState = .idle
    @Published var isRunning = false
    @Published var connectionState: AIConnectionState = .notConfigured
    @Published var revenue: Double = 0
    @Published var spend: Double = 0
    @Published var opportunities: [Opportunity] = []
    @Published var missions: [Mission] = []
    @Published var approvals: [ApprovalRequest] = []
    @Published var artifacts: [ActionArtifact] = []
    @Published var activity: [ActivityEvent] = []
    @Published var ledger: [LedgerEntry] = []
    @Published var cycleProgress: Double = 0
    @Published var currentTask = "Ready"
    @Published var currentDetail = "Add an API key, then run a mission."
    @Published var lastError: String? = nil
    @Published var apiKeyInput: String = ""

    private let store = LocalStore()
    private let ai = OpenAIClient()
    private var runTask: Task<Void, Never>?

    init() {
        load()
        apiKeyInput = KeychainStore.read(account: "openai_api_key")
        connectionState = apiKeyInput.isEmpty ? .notConfigured : .failed
        if missions.isEmpty {
            missions = [Mission(id: UUID(), title: "Zero-Cost Income", objective: "Find legitimate low-cost or £0-startup opportunities with the fastest realistic path to first revenue.", progress: 0, status: "Ready", createdAt: Date())]
        }
        if activity.isEmpty { log("Agent ready", "No fake opportunities are generated. Live results only appear after an AI request succeeds.", .idle) }
    }

    var activeMission: Mission? { missions.first }
    var hasKey: Bool { !KeychainStore.read(account: "openai_api_key").isEmpty }
    var net: Double { revenue - spend }

    func saveAPIKey() {
        let key = apiKeyInput.trimmingCharacters(in: .whitespacesAndNewlines)
        if key.isEmpty { KeychainStore.delete(account: "openai_api_key"); connectionState = .notConfigured }
        else { KeychainStore.save(key, account: "openai_api_key"); connectionState = .failed }
        save()
    }

    func testAI() async {
        let key = KeychainStore.read(account: "openai_api_key")
        guard !key.isEmpty else { connectionState = .notConfigured; lastError = "Add your API key first."; return }
        connectionState = .testing; currentTask = "Testing AI"; currentDetail = "Checking the API key without running a mission."
        do {
            let ok = try await ai.validateKey(key)
            connectionState = ok ? .live : .failed
            currentTask = ok ? "AI connected" : "Connection failed"
            currentDetail = ok ? "The model service is reachable." : "The API key was rejected."
            log(ok ? "AI connected" : "AI rejected", currentDetail, ok ? .success : .warning)
        } catch { connectionState = .failed; lastError = error.localizedDescription; currentTask = "Connection failed"; currentDetail = error.localizedDescription; log("AI offline", error.localizedDescription, .warning) }
    }

    func toggleAgent() { isRunning ? stop() : runMission() }

    func runMission() {
        guard !isRunning else { return }
        let key = KeychainStore.read(account: "openai_api_key")
        guard !key.isEmpty else { lastError = "Add an OpenAI API key in Settings first."; currentTask = "AI setup required"; currentDetail = "Settings → AI connection → API key"; state = .warning; return }
        guard let mission = activeMission else { return }
        lastError = nil; isRunning = true; cycleProgress = 0.05; state = .scanning
        currentTask = "Starting live research"; currentDetail = mission.objective
        log("Mission started", "Sending the mission to \(selectedModel.label).", .scanning)
        runTask = Task { [weak self] in await self?.performMission(mission, key: key) }
    }

    func stop() {
        runTask?.cancel(); runTask = nil; isRunning = false; state = .idle; cycleProgress = 0
        currentTask = "Agent paused"; currentDetail = "The current request was cancelled locally."
        log("Agent paused", currentDetail, .idle)
    }

    private func performMission(_ mission: Mission, key: String) async {
        state = .researching; cycleProgress = 0.28; currentTask = "AI researching the web"; currentDetail = "Looking for current evidence and sources."
        log("Live web research", "The AI is searching current sources. This may take a little while.", .researching)
        do {
            let result = try await ai.researchMission(objective: mission.objective, region: region, model: selectedModel, key: key)
            if Task.isCancelled { return }
            state = .comparing; cycleProgress = 0.74; currentTask = "Scoring real findings"; currentDetail = result.summary
            log("Research returned", result.summary, .comparing)

            let converted = result.opportunities.map { o in
                Opportunity(id: UUID(), title: o.title, category: o.category, score: min(100,max(0,o.score)), startupCost: max(0,o.startup_cost), estimatedRevenueLow: max(0,o.estimated_revenue_low), estimatedRevenueHigh: max(o.estimated_revenue_low,o.estimated_revenue_high), evidence: o.evidence, whyNow: o.why_now, nextActions: o.next_actions, sources: o.sources.compactMap { s in URL(string: s.url) == nil ? nil : SourceLink(title:s.title,url:s.url) }, status: "Live researched")
            }.sorted { $0.score > $1.score }

            opportunities = converted
            if let idx = missions.firstIndex(where: {$0.id == mission.id}) { missions[idx].progress = 0.7; missions[idx].status = "Researched" }
            cycleProgress = 0.92; state = .building; currentTask = "Preparing next decision"; currentDetail = "Choosing the strongest candidate that passed the evidence check."

            if let best = converted.first {
                if mode == .watch {
                    state = .success; cycleProgress = 1; currentTask = "Research complete"; currentDetail = "WATCH mode recorded \(converted.count) opportunities and stopped before preparing actions."
                    log("Research complete", "Top result: \(best.title) (\(best.score)/100).", .success)
                } else {
                    approvals = [ApprovalRequest(id: UUID(), opportunityID: best.id, title: "Prepare execution pack", reason: "\(best.title) scored \(best.score)/100. Approval lets the AI prepare outreach/copy/checklists; it will not send or spend.", estimatedCost: 0, risk: "Low", createdAt: Date())]
                    state = .waitingApproval; cycleProgress = 1; currentTask = "Approval required"; currentDetail = "Review the real sources before asking the AI to prepare the action pack."
                    log("Approval required", "Prepare the next step for \(best.title).", .waitingApproval)
                }
            } else {
                state = .warning; currentTask = "No usable opportunities"; currentDetail = "The live research returned nothing that met the requested structure."
            }
            connectionState = .live
        } catch {
            if Task.isCancelled { return }
            lastError = error.localizedDescription; connectionState = .failed; state = .warning; cycleProgress = 0
            currentTask = "AI request failed"; currentDetail = error.localizedDescription
            log("Mission failed", error.localizedDescription, .warning)
        }
        isRunning = false; runTask = nil; save()
    }

    func approve(_ request: ApprovalRequest) {
        guard let opp = opportunities.first(where: {$0.id == request.opportunityID}), let mission = activeMission else { return }
        approvals.removeAll { $0.id == request.id }
        let key = KeychainStore.read(account: "openai_api_key")
        guard !key.isEmpty else { lastError = "API key missing."; return }
        isRunning = true; state = .building; cycleProgress = 0.2; currentTask = "AI preparing execution pack"; currentDetail = opp.title
        log("Action approved", "Preparing work for \(opp.title). No external action is sent automatically.", .building)
        runTask = Task { [weak self] in
            guard let self else { return }
            do {
                let content = try await self.ai.prepareAction(opportunity: opp, objective: mission.objective, model: self.selectedModel, key: key)
                if Task.isCancelled { return }
                self.artifacts.insert(ActionArtifact(id: UUID(), opportunityID: opp.id, createdAt: Date(), title: opp.title, kind: "Execution Pack", content: content), at: 0)
                if let i = self.opportunities.firstIndex(where: {$0.id == opp.id}) { self.opportunities[i].status = "Execution pack ready" }
                if let i = self.missions.firstIndex(where: {$0.id == mission.id}) { self.missions[i].progress = 0.9; self.missions[i].status = "Action pack ready" }
                self.state = .success; self.cycleProgress = 1; self.currentTask = "Execution pack ready"; self.currentDetail = "Open Work to review the AI-created plan and copy."
                self.log("Work created", "Execution pack created for \(opp.title).", .success)
            } catch {
                self.lastError = error.localizedDescription; self.state = .warning; self.currentTask = "Action preparation failed"; self.currentDetail = error.localizedDescription; self.log("Action failed", error.localizedDescription, .warning)
            }
            self.isRunning = false; self.runTask = nil; self.save()
        }
    }

    func reject(_ request: ApprovalRequest) { approvals.removeAll{$0.id==request.id}; log("Rejected", request.title, .warning); save() }

    func updateMission(title: String, objective: String) {
        if missions.isEmpty { missions=[Mission(id:UUID(),title:title,objective:objective,progress:0,status:"Ready",createdAt:Date())] }
        else { missions[0].title=title; missions[0].objective=objective; missions[0].progress=0; missions[0].status="Ready" }
        opportunities=[]; approvals=[]; save(); log("Mission updated", objective, .idle)
    }

    func addRevenue(_ amount: Double, note: String) { guard amount>0 else{return}; revenue+=amount; ledger.insert(LedgerEntry(id:UUID(),timestamp:Date(),type:"Revenue",amount:amount,note:note),at:0); log("Revenue recorded",String(format:"£%.2f — %@",amount,note),.success); save() }
    func addExpense(_ amount: Double, note: String) { guard amount>0 else{return}; spend+=amount; ledger.insert(LedgerEntry(id:UUID(),timestamp:Date(),type:"Expense",amount:-amount,note:note),at:0); save() }

    private func log(_ title:String,_ detail:String,_ s:AgentState){ activity.insert(ActivityEvent(title:title,detail:detail,state:s),at:0); if activity.count>100{activity=Array(activity.prefix(100))} }
    private func load(){ guard let x=store.load() else{return}; mode=x.mode; selectedModel=x.selectedModel; region=x.region; revenue=x.revenue; spend=x.spend; opportunities=x.opportunities; missions=x.missions; approvals=x.approvals; artifacts=x.artifacts; activity=x.activity; ledger=x.ledger }
    func save(){ store.save(Snapshot(mode:mode,selectedModel:selectedModel,region:region,revenue:revenue,spend:spend,opportunities:opportunities,missions:missions,approvals:approvals,artifacts:artifacts,activity:activity,ledger:ledger)) }
}
