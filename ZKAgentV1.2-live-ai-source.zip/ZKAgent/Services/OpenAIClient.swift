import Foundation

enum OpenAIClientError: LocalizedError {
    case invalidKey, badResponse, api(String), noText, invalidJSON(String)
    var errorDescription: String? {
        switch self {
        case .invalidKey: return "The API key is empty or invalid."
        case .badResponse: return "The AI service returned an invalid response."
        case .api(let m): return m
        case .noText: return "The AI returned no usable result."
        case .invalidJSON(let m): return "Could not read the AI result: \(m)"
        }
    }
}

struct OpenAIClient {
    private let base = URL(string: "https://api.openai.com/v1")!

    func validateKey(_ key: String) async throws -> Bool {
        guard key.hasPrefix("sk-") else { throw OpenAIClientError.invalidKey }
        var req = URLRequest(url: base.appendingPathComponent("models"))
        req.setValue("Bearer \(key)", forHTTPHeaderField: "Authorization")
        let (_, response) = try await URLSession.shared.data(for: req)
        guard let http = response as? HTTPURLResponse else { throw OpenAIClientError.badResponse }
        return (200..<300).contains(http.statusCode)
    }

    func researchMission(objective: String, region: String, model: AgentModel, key: String) async throws -> AgentResearchResult {
        let schema: [String: Any] = [
            "type": "object",
            "additionalProperties": false,
            "properties": [
                "summary": ["type": "string"],
                "opportunities": [
                    "type": "array", "minItems": 1, "maxItems": 5,
                    "items": [
                        "type": "object", "additionalProperties": false,
                        "properties": [
                            "title": ["type": "string"],
                            "category": ["type": "string"],
                            "score": ["type": "integer", "minimum": 0, "maximum": 100],
                            "startup_cost": ["type": "number", "minimum": 0],
                            "estimated_revenue_low": ["type": "number", "minimum": 0],
                            "estimated_revenue_high": ["type": "number", "minimum": 0],
                            "evidence": ["type": "string"],
                            "why_now": ["type": "string"],
                            "next_actions": ["type": "array", "minItems": 2, "maxItems": 6, "items": ["type": "string"]],
                            "sources": ["type": "array", "minItems": 1, "maxItems": 6, "items": [
                                "type": "object", "additionalProperties": false,
                                "properties": ["title": ["type":"string"], "url": ["type":"string"]],
                                "required": ["title", "url"]
                            ]]
                        ],
                        "required": ["title","category","score","startup_cost","estimated_revenue_low","estimated_revenue_high","evidence","why_now","next_actions","sources"]
                    ]
                ]
            ],
            "required": ["summary", "opportunities"]
        ]

        let system = """
        You are ZK Agent, an evidence-driven autonomous opportunity researcher. Your job is to find legitimate, practical income opportunities that a single person can act on quickly. Use live web search before making recommendations. Never fabricate demand, buyers, job requests, prices, or source URLs. Prefer opportunities with low startup cost and a short path to first revenue. Do not recommend gambling, deceptive/spam activity, high-risk speculative trading, regulated goods, or anything illegal. Treat revenue figures as rough estimates, not guarantees. Sources must be real pages you used and must support the evidence. If evidence is weak, lower the score. Return only the requested structured result.
        """
        let user = "Mission: \(objective)\nRegion/context: \(region)\nFind the best 3-5 current opportunities and concrete next actions."

        let body: [String: Any] = [
            "model": model.rawValue,
            "reasoning": ["effort": model == .luna ? "medium" : "high"],
            "input": [
                ["role": "system", "content": [["type":"input_text", "text":system]]],
                ["role": "user", "content": [["type":"input_text", "text":user]]]
            ],
            "tools": [["type": "web_search"]],
            "tool_choice": "auto",
            "text": ["format": ["type":"json_schema", "name":"agent_research", "strict":true, "schema":schema]],
            "max_output_tokens": 7000
        ]
        let data = try await postResponses(body: body, key: key)
        let text = try extractOutputText(data)
        do { return try JSONDecoder().decode(AgentResearchResult.self, from: Data(text.utf8)) }
        catch { throw OpenAIClientError.invalidJSON(error.localizedDescription) }
    }

    func prepareAction(opportunity: Opportunity, objective: String, model: AgentModel, key: String) async throws -> String {
        let sources = opportunity.sources.map { "- \($0.title): \($0.url)" }.joined(separator: "\n")
        let prompt = """
        Mission: \(objective)
        Selected opportunity: \(opportunity.title)
        Evidence: \(opportunity.evidence)
        Why now: \(opportunity.whyNow)
        Sources:\n\(sources)
        Existing next actions:\n\(opportunity.nextActions.enumerated().map { "\($0.offset+1). \($0.element)" }.joined(separator: "\n"))

        Create a practical execution pack for this opportunity. Include: first 60-minute plan, exact research/verification checklist, a concise outreach message or listing copy when relevant, what NOT to claim, success metric for the first test, and a stop condition. Do not send messages, spend money, or claim actions were completed. This is a preparation step only.
        """
        let body: [String: Any] = [
            "model": model.rawValue,
            "reasoning": ["effort": "medium"],
            "input": [["role":"user", "content":[["type":"input_text", "text":prompt]]]],
            "max_output_tokens": 4500
        ]
        let data = try await postResponses(body: body, key: key)
        return try extractOutputText(data)
    }

    private func postResponses(body: [String: Any], key: String) async throws -> Data {
        guard !key.isEmpty else { throw OpenAIClientError.invalidKey }
        var req = URLRequest(url: base.appendingPathComponent("responses"))
        req.httpMethod = "POST"
        req.setValue("Bearer \(key)", forHTTPHeaderField: "Authorization")
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.httpBody = try JSONSerialization.data(withJSONObject: body)
        req.timeoutInterval = 120
        let (data, response) = try await URLSession.shared.data(for: req)
        guard let http = response as? HTTPURLResponse else { throw OpenAIClientError.badResponse }
        if !(200..<300).contains(http.statusCode) {
            if let obj = try? JSONSerialization.jsonObject(with: data) as? [String:Any],
               let err = obj["error"] as? [String:Any], let msg = err["message"] as? String {
                throw OpenAIClientError.api(msg)
            }
            throw OpenAIClientError.api("AI request failed (HTTP \(http.statusCode)).")
        }
        return data
    }

    private func extractOutputText(_ data: Data) throws -> String {
        guard let root = try JSONSerialization.jsonObject(with: data) as? [String:Any],
              let output = root["output"] as? [[String:Any]] else { throw OpenAIClientError.badResponse }
        for item in output where item["type"] as? String == "message" {
            if let content = item["content"] as? [[String:Any]] {
                for part in content where part["type"] as? String == "output_text" {
                    if let text = part["text"] as? String, !text.isEmpty { return text }
                }
            }
        }
        if let text = root["output_text"] as? String, !text.isEmpty { return text }
        throw OpenAIClientError.noText
    }
}
