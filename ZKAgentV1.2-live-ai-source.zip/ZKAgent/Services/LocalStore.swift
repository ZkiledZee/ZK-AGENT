import Foundation

struct Snapshot: Codable {
    var mode: AgentMode
    var selectedModel: AgentModel
    var region: String
    var revenue: Double
    var spend: Double
    var opportunities: [Opportunity]
    var missions: [Mission]
    var approvals: [ApprovalRequest]
    var artifacts: [ActionArtifact]
    var activity: [ActivityEvent]
    var ledger: [LedgerEntry]
}

struct LocalStore {
    private var url: URL { FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0].appendingPathComponent("zkagent-state.json") }
    func load() -> Snapshot? {
        guard let data = try? Data(contentsOf: url) else { return nil }
        return try? JSONDecoder().decode(Snapshot.self, from: data)
    }
    func save(_ snapshot: Snapshot) {
        let dir = url.deletingLastPathComponent()
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        let enc = JSONEncoder(); enc.outputFormatting = [.prettyPrinted]
        if let data = try? enc.encode(snapshot) { try? data.write(to: url, options: .atomic) }
    }
}
