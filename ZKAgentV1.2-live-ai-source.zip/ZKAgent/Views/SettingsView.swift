import SwiftUI

struct SettingsView:View{
    @EnvironmentObject var app:AppState
    @State private var showKey=false
    var body:some View{NavigationStack{Form{
        Section("AI connection"){
            HStack{Label("Status",systemImage:"brain.head.profile");Spacer();Text(app.connectionState.rawValue).font(.caption.bold()).foregroundStyle(app.connectionState == .live ? .green:.secondary)}
            if showKey{TextField("sk-...",text:$app.apiKeyInput).textInputAutocapitalization(.never).autocorrectionDisabled()}else{SecureField("OpenAI API key",text:$app.apiKeyInput).textInputAutocapitalization(.never)}
            Toggle("Show key",isOn:$showKey)
            Button("Save key to iPhone Keychain"){app.saveAPIKey()}
            Button{Task{await app.testAI()}}label:{HStack{Text(app.connectionState == .testing ? "Testing…":"Test AI connection");if app.connectionState == .testing{Spacer();ProgressView()}}}.disabled(app.connectionState == .testing)
            Text("Personal-build mode: the key is stored in iOS Keychain, not in the app's JSON state. A server backend is safer for a distributed app.").font(.caption).foregroundStyle(.secondary)
        }
        Section("Agent"){
            Picker("Model",selection:$app.selectedModel){ForEach(AgentModel.allCases){m in Text(m.label).tag(m)}}.onChange(of:app.selectedModel){_ in app.save()}
            TextField("Region / market",text:$app.region).onSubmit{app.save()}
            Picker("Autonomy",selection:$app.mode){ForEach(AgentMode.allCases,id:\.self){Text($0.rawValue).tag($0)}}.onChange(of:app.mode){_ in app.save()}
            Text("WATCH researches only. ASSIST asks before preparing work. AUTOPILOT is intentionally treated like ASSIST until external tools have explicit per-tool permissions.").font(.caption).foregroundStyle(.secondary)
        }
        Section("What works now"){
            Label("Live AI web research",systemImage:"globe")
            Label("Real source links",systemImage:"link")
            Label("Opportunity scoring",systemImage:"chart.bar")
            Label("Approval-gated execution packs",systemImage:"hand.raised")
            Label("Mission editing + persistent memory",systemImage:"brain")
        }
        Section("Not automated yet"){
            Text("The app does not send email/DMs, publish websites, place orders, spend money, or move funds. Those require separate account integrations and explicit permissions.").font(.caption).foregroundStyle(.secondary)
        }
    }.navigationTitle("Settings")}}
}
