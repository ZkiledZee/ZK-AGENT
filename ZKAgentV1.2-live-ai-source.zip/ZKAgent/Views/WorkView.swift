import SwiftUI

struct WorkView: View {
    @EnvironmentObject var app: AppState
    var body: some View { NavigationStack { List { if app.artifacts.isEmpty { ContentUnavailableView("No work yet", systemImage:"hammer", description:Text("Approve a researched opportunity and the AI will create an execution pack here.")) } else { ForEach(app.artifacts){a in NavigationLink{ArtifactDetailView(artifact:a)}label:{VStack(alignment:.leading,spacing:5){Text(a.title).font(.headline);Text(a.kind).font(.caption).foregroundStyle(.secondary);Text(a.createdAt,style:.relative).font(.caption2).foregroundStyle(.tertiary)}} } } }.navigationTitle("Work") } }
}
struct ArtifactDetailView:View{let artifact:ActionArtifact;var body:some View{ScrollView{VStack(alignment:.leading,spacing:16){Text(artifact.title).font(.title2.bold());Text(artifact.content).textSelection(.enabled);ShareLink(item:artifact.content){Label("Share execution pack",systemImage:"square.and.arrow.up")}.buttonStyle(.borderedProminent).tint(.white).foregroundStyle(.black)}.padding()}.navigationTitle("Execution Pack").navigationBarTitleDisplayMode(.inline)}}
